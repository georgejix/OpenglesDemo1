package com.dftc.dvrservice.render

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.opengl.EGLContext

abstract class CombineRender {
    var mEglContext: EGLContext? = null
    open fun initEgl(f: (glContext: EGLContext) -> Unit) {}
    open fun release() {}
    open fun runInHandler(f: (() -> Unit)) {}
    open fun createSv(f: ((st: SurfaceTexture) -> Unit)) {}
    open fun close() {}
    open fun updateTopImg(bitmap: Bitmap) {}
    open fun draw(f: ((tid: Int) -> Unit)?) {}
}