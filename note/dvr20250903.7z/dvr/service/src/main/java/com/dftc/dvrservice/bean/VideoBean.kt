package com.dftc.dvrservice.bean

data class VideoBean(val startTime: Long, val endTime: Long, var path: String)