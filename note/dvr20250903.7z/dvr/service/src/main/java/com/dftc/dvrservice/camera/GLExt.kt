package com.dftc.dvrservice.camera

import android.graphics.Bitmap
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.GLUtils
import javax.microedition.khronos.opengles.GL10

fun compileShader(type: Int, shaderCode: String): Int {
    val shaderId = GLES30.glCreateShader(type)
    return if (shaderId != 0) {
        GLES30.glShaderSource(shaderId, shaderCode)
        GLES30.glCompileShader(shaderId)
        val compileStatus = IntArray(1)
        GLES30.glGetShaderiv(shaderId, GLES30.GL_COMPILE_STATUS, compileStatus, 0)
        if (compileStatus[0] == 0) {
            val logInfo = GLES30.glGetShaderInfoLog(shaderId)
            System.err.println(logInfo)
            GLES30.glDeleteShader(shaderId)
            return 0
        }
        shaderId
    } else {
        0
    }
}

fun linkProgram(vertexShaderId: Int, fragmentShaderId: Int): Int {
    val programId = GLES30.glCreateProgram()
    return if (programId != 0) {
        GLES30.glAttachShader(programId, vertexShaderId)
        GLES30.glAttachShader(programId, fragmentShaderId)
        GLES30.glLinkProgram(programId)
        val linkStatus = IntArray(1)
        GLES30.glGetProgramiv(programId, GLES30.GL_LINK_STATUS, linkStatus, 0)
        if (linkStatus[0] == 0) {
            val logInfo = GLES30.glGetProgramInfoLog(programId)
            GLES30.glDeleteProgram(programId)
            return 0
        }
        programId
    } else {
        0
    }
}

fun loadOESTexture(): Int {
    val textureIds = IntArray(1)
    GLES30.glGenTextures(1, textureIds, 0)
    GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureIds[0])
    GLES30.glTexParameterf(
        GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GL10.GL_TEXTURE_MIN_FILTER, GL10.GL_NEAREST.toFloat()
    )
    GLES30.glTexParameterf(
        GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GL10.GL_TEXTURE_MAG_FILTER, GL10.GL_LINEAR.toFloat()
    )
    GLES30.glTexParameterf(
        GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GL10.GL_TEXTURE_WRAP_S, GL10.GL_CLAMP_TO_EDGE.toFloat()
    )
    GLES30.glTexParameterf(
        GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GL10.GL_TEXTURE_WRAP_T, GL10.GL_CLAMP_TO_EDGE.toFloat()
    )
    GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, 0)
    return textureIds[0]
}

fun loadTexture(): Int {
    var textureIds = IntArray(1)
    GLES30.glGenTextures(1, textureIds, 0)
    GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureIds[0])
    GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
    GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
    GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
    GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
    GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
    return textureIds[0]
}

fun updateTexture(tid: Int, bitmap: Bitmap) {
    GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tid)
    GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bitmap, 0)
    GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
    bitmap.recycle()
    GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
}