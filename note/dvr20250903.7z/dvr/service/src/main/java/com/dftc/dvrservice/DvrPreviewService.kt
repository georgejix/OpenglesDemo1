package com.dftc.dvrservice

import android.app.Service
import android.content.Intent
import android.os.IBinder

class DvrPreviewService : Service() {
    private val TAG = javaClass.simpleName
    private val mDvrPreviewImpl: DvrPreviewImpl by lazy { DvrPreviewImpl() }

    override fun onCreate() {
        super.onCreate()
        LogPrint.Info(TAG, "onCreate")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        LogPrint.Info(TAG, "onStartCommand flags=$flags startId=$startId")
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        LogPrint.Info(TAG, "onBind")
        return mDvrPreviewImpl
    }

    override fun onUnbind(intent: Intent?): Boolean {
        LogPrint.Info(TAG, "onUnbind")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        LogPrint.Info(TAG, "onDestroy")
        mDvrPreviewImpl.removePreviewSurface(0)
        super.onDestroy()
    }
}