package com.dftc.dvrservice.render

import android.opengl.EGLContext
import android.view.Surface

interface PreviewRender {
    fun initEgl(sv: Surface, sharedContext: EGLContext)
    fun changeView(w: Int, h: Int)
    fun release()
    fun draw(textureId: Int)
}