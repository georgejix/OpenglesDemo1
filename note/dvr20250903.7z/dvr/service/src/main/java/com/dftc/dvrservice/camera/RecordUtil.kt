package com.dftc.dvrservice.camera

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Bundle
import android.os.SystemClock
import android.view.Surface
import com.dftc.dvrservice.DvrServiceApplication
import com.dftc.dvrservice.LogPrint
import com.dftc.dvrservice.bean.CutVideoBean
import com.dftc.dvrservice.bean.VideoBean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.nio.ByteBuffer
import java.text.SimpleDateFormat


class RecordUtil(val mCameraId: String, val mWidth: Int, val mHeight: Int) {
    private val TAG = javaClass.simpleName
    private var mRecordSurface: Surface? = null
    private val mSdf by lazy { SimpleDateFormat("yyyy-MM-dd-HH-mm-ss") }

    private var mMediaFormat: MediaFormat? = null
    private var mMediaCodec: MediaCodec? = null
    private var mMediaMuxer: MediaMuxer? = null
    private var mSecondMediaMuxer: MediaMuxer? = null
    private var mRecordPath: String = ""
    private var mSecondRecordPath: String = ""
    private var mVideoTrackId = -1
    private var mAudioTrackId = -1
    private val mMaxVideoDuration = 20 * 1000
    private val mInitSecondPrepareTime = 1000L
    private val mInitSecondMuxer = mMaxVideoDuration - mInitSecondPrepareTime
    private var mStartTimeStamp = 0L
    private val mCutVideoUtil by lazy { CutVideoUtil() }
    private val mRecordQueue = ArrayDeque<VideoBean>(5)
    private val mCutJobQueue = ArrayDeque<CutVideoBean>(5)

    fun getSurface(): Surface? = mRecordSurface

    private val mMediaCodecCb = object : MediaCodec.Callback() {
        override fun onInputBufferAvailable(codec: MediaCodec, index: Int) {
        }

        override fun onOutputBufferAvailable(
            codec: MediaCodec, index: Int, info: MediaCodec.BufferInfo
        ) {
            codec.getOutputBuffer(index)?.let { data ->
                if (SystemClock.elapsedRealtime() - mStartTimeStamp >= mMaxVideoDuration) {
                    if (MediaCodec.BUFFER_FLAG_KEY_FRAME == info.flags) {
                        mSecondMediaMuxer = mMediaMuxer.also {
                            mMediaMuxer = mSecondMediaMuxer
                        }
                        mSecondRecordPath = mRecordPath.also {
                            mRecordPath = mSecondRecordPath
                        }
                        val vid = mVideoTrackId
                        val aid = mAudioTrackId
                        val startTime = mStartTimeStamp
                        CoroutineScope(Dispatchers.IO).launch {
                            stopMuxer(mSecondMediaMuxer, vid, aid, startTime, mSecondRecordPath)
                            mSecondMediaMuxer = null
                            mSecondRecordPath = ""
                        }
                        mStartTimeStamp = SystemClock.elapsedRealtime()
                        mMediaMuxer?.writeSampleData(mVideoTrackId, data, info)
                    } else {
                        mMediaMuxer?.writeSampleData(mVideoTrackId, data, info)
                        val params = Bundle()
                        params.putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
                        mMediaCodec?.setParameters(params)
                    }
                } else {
                    if (null == mSecondMediaMuxer &&
                        SystemClock.elapsedRealtime() - mStartTimeStamp >= mInitSecondMuxer
                    ) {
                        initMediaMuxer(mInitSecondPrepareTime)
                    }
                    mMediaMuxer?.writeSampleData(mVideoTrackId, data, info)
                }
            }
            codec.releaseOutputBuffer(index, false)
        }

        override fun onError(codec: MediaCodec, e: MediaCodec.CodecException) {
            LogPrint.Debug(TAG, "onError")
        }

        override fun onOutputFormatChanged(codec: MediaCodec, format: MediaFormat) {
            LogPrint.Debug(TAG, "onOutputFormatChanged")
            mMediaFormat = format
            mVideoTrackId = mMediaMuxer?.addTrack(format) ?: -1
            mMediaMuxer?.start()
            mStartTimeStamp = SystemClock.elapsedRealtime()
        }
    }

    fun start() {
        mMediaCodec ?: initMediaCodec()
        initMediaMuxer(2000)
    }

    private fun initMediaCodec() {
        LogPrint.Debug(TAG, "initMediaCodec")
        val format =
            MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, mWidth, mHeight)
                .also { format ->
                    format.setInteger(
                        MediaFormat.KEY_COLOR_FORMAT,
                        MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
                    )
                    format.setInteger(MediaFormat.KEY_BIT_RATE, 5 * 1024 * 1024)
                    format.setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                    format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
                }

        mMediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        mMediaCodec?.setCallback(mMediaCodecCb)
        mMediaCodec?.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        mMediaCodec?.setInputSurface(MediaCodec.createPersistentInputSurface().also {
            mRecordSurface = it
        })
        mMediaCodec?.start()
    }

    private fun initMediaMuxer(addTime: Long) {
        val path =
            DvrServiceApplication.getOutputVideoPath(mSdf.format(System.currentTimeMillis() + addTime))
        LogPrint.Debug(TAG, "initMediaMuxer path=$path")
        File(path).let { file ->
            if (file.exists()) file.delete()
            file.createNewFile()
        }
        MediaMuxer(path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4).let { muxer ->
            mMediaFormat?.let { format ->
                mVideoTrackId = muxer.addTrack(format)
                muxer.start()
            }
            mMediaMuxer?.let {
                mSecondMediaMuxer = muxer
                mSecondRecordPath = path
                LogPrint.Debug(TAG, "initMediaMuxer mSecondMediaMuxer")
            } ?: let {
                mMediaMuxer = muxer
                mRecordPath = path
                LogPrint.Debug(TAG, "initMediaMuxer mMediaMuxer")
            }
        }
    }

    private fun stopMuxer(
        muxer: MediaMuxer?, videoTrackId: Int, audioTrackId: Int, startTime: Long, path: String
    ) {
        LogPrint.Debug(TAG, "stopMuxer muxer=$muxer")
        val info = MediaCodec.BufferInfo()
        val data = ByteBuffer.allocate(0)
        info.set(0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
        if (videoTrackId >= 0) muxer?.writeSampleData(videoTrackId, data, info)
        if (audioTrackId >= 0) muxer?.writeSampleData(audioTrackId, data, info)
        muxer?.stop()
        muxer?.release()
        mRecordQueue.add(VideoBean(startTime, SystemClock.elapsedRealtime(), path).also {
            LogPrint.Info(
                TAG, "mRecordQueue add ${it.startTime / 1000} to ${it.endTime / 1000} ${it.path}"
            )
        })
        judgeCutVideo()
    }

    fun release() {
        mMediaMuxer?.let { muxer ->
            val info = MediaCodec.BufferInfo()
            val data = ByteBuffer.allocate(0)
            info.set(0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            mVideoTrackId.takeIf { it >= 0 }?.let { muxer.writeSampleData(it, data, info) }
            mAudioTrackId.takeIf { it >= 0 }?.let { muxer.writeSampleData(it, data, info) }
            muxer.stop()
            muxer.release()
            mMediaMuxer = null
        }
        mMediaCodec?.stop()
        mMediaCodec?.release()
        mMediaCodec = null
        mRecordSurface = null
    }

    fun addCutJob(duration: Long) {
        val time = SystemClock.elapsedRealtime()
        mCutJobQueue.add(CutVideoBean(time - duration * 1000, time + (duration + 1) * 1000).also {
            LogPrint.Info(TAG, "add cut job from ${it.startTime / 1000} to ${it.endTime / 1000}")
        })
    }

    private fun judgeCutVideo() {
        LogPrint.Info(
            TAG,
            "origin mCutJobQueue.size=${mCutJobQueue.size} mRecordQueue.size=${mRecordQueue.size}"
        )
        while (mCutJobQueue.isNotEmpty() && mCutJobQueue.first().endTime <= mRecordQueue.last().endTime) {
            val cutBean = mCutJobQueue.first()
            LogPrint.Info(
                TAG, "judgeCutVideo ${cutBean.startTime / 1000} to ${cutBean.endTime / 1000}"
            )
            val list = ArrayList(mRecordQueue.filter {
                (cutBean.startTime < it.startTime && it.startTime < cutBean.endTime) ||
                        (cutBean.startTime < it.endTime && it.endTime < cutBean.endTime)
            })
            mCutVideoUtil.cut(list, cutBean)
            mCutJobQueue.removeFirst()
        }
        while (mRecordQueue.size > 3) {
            LogPrint.Info(TAG, "mRecordQueue removeFirst")
            mRecordQueue.removeFirst()
        }
        LogPrint.Info(
            TAG, "mCutJobQueue.size=${mCutJobQueue.size} mRecordQueue.size=${mRecordQueue.size}"
        )
    }
}