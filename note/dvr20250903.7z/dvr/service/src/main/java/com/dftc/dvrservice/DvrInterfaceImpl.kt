package com.dftc.dvrservice

import android.view.Surface
import com.dftc.dvraidl.DvrAidlConstant
import com.dftc.dvraidl.IDvrPreview
import com.dftc.dvrservice.camera.CameraUtil

class DvrPreviewImpl : IDvrPreview.Stub() {
    private val TAG = javaClass.simpleName

    override fun setPreviewSurface(type: Int, surface: Surface?) {
        LogPrint.Info(TAG, "setPreviewSurface type=$type")
        surface?.let {
            when (type) {
                DvrAidlConstant.PREVIEW_TYPE_DVR ->
                    CameraUtil.addPreview(surface, CameraUtil.mDvrCameraBean)
            }
        }
    }

    override fun setPreviewSize(type: Int, width: Int, height: Int) {
        LogPrint.Info(TAG, "setPreviewSize type=$type width=$width height=$height")
        when (type) {
            DvrAidlConstant.PREVIEW_TYPE_DVR ->
                CameraUtil.changePreviewView(CameraUtil.mDvrCameraBean, width, height)
        }
    }

    override fun removePreviewSurface(type: Int) {
        LogPrint.Info(TAG, "removePreviewSurface type=$type")
        when (type) {
            DvrAidlConstant.PREVIEW_TYPE_DVR ->
                CameraUtil.closeCameraPreview(CameraUtil.mDvrCameraBean)

            else -> {
                CameraUtil.closeCameraPreview(CameraUtil.mDvrCameraBean)
            }
        }
    }
}