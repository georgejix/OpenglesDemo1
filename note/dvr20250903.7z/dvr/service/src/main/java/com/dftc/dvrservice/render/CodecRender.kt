package com.dftc.dvrservice.render

import android.opengl.EGLContext
import android.view.Surface

interface CodecRender {
    fun initEgl(sv: Surface, sharedContext: EGLContext)
    fun release()
    fun draw(textureId: Int)
}