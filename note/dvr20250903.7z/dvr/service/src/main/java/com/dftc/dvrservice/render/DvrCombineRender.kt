package com.dftc.dvrservice.render

import android.graphics.Bitmap
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.Matrix
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import com.dftc.dvrservice.LogPrint
import com.dftc.dvrservice.camera.compileShader
import com.dftc.dvrservice.camera.linkProgram
import com.dftc.dvrservice.camera.loadOESTexture
import com.dftc.dvrservice.camera.loadTexture
import com.dftc.dvrservice.camera.updateTexture
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer

class DvrCombineRender(val renderName: String, val width: Int, val height: Int) : CombineRender() {
    private val TAG: String = "${javaClass.simpleName}$renderName"
    private var mEglDisplay: EGLDisplay? = null
    private var mEglSurface: EGLSurface? = null
    private val mHandlerThread by lazy { HandlerThread(renderName) }
    private val mHandler by lazy {
        mHandlerThread.start()
        Handler(mHandlerThread.looper)
    }
    private val mVertexTextureArray = floatArrayOf(
        -1f, -1f, 1f, 1f,
        -1f, 1f, 1f, 0f,
        1f, 1f, 0f, 0f,
        1f, -1f, 0f, 1f
    )

    private val mIndexArray = intArrayOf(0, 1, 2, 0, 2, 3)
    private val mVertexTextureBuffer: FloatBuffer by lazy {
        ByteBuffer.allocateDirect(mVertexTextureArray.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().also {
                it.put(mVertexTextureArray).position(0)
            }
    }
    private val mIndexBuffer: IntBuffer by lazy {
        ByteBuffer.allocateDirect(mIndexArray.size * 4)
            .order(ByteOrder.nativeOrder()).asIntBuffer().also {
                it.put(mIndexArray).position(0)
            }
    }
    private var mProgramId = 0
    private var mPositionLocation = 0
    private var mTexturePositionLocation = 1
    private var mImgLocation = 0
    private var mTopImgLocation = 0
    private var mMatrixLocation = 0
    private val mMatrixArray = FloatArray(16)
    private var mTopImgTextureId = -1
    private var mImgTextureId = -1
    private var mImgSurfaceTexture: SurfaceTexture? = null
    private var mOutputTextureId = 0
    private var mFrameBufferId = 0

    private val vertexShaderCode = """
        #version 300 es
        in vec4 position;
        in vec2 texturePositionIn;
        out vec2 texturePosition;
        out vec2 vertexPosition;
        uniform mat4 matrix;
        void main() {
            gl_Position = matrix * position;
            texturePosition = texturePositionIn;
            vertexPosition = position.xy;
        }
    """.trimIndent()
    private val fragmentShaderCode = """
        #version 300 es
        #extension GL_OES_EGL_image_external_essl3 : require
        precision mediump float;
        uniform samplerExternalOES img;
        uniform sampler2D topImg;
        in vec2 texturePosition;
        in vec2 vertexPosition;
        out vec4 fragColor;
        vec2 leftBottom = vec2(-1.0,0.8);
        vec2 rightTop = vec2(1.0,1.0);
        void main() {
            if(vertexPosition.x >= leftBottom.x && vertexPosition.x <= rightTop.x &&
                vertexPosition.y >= leftBottom.y && vertexPosition.y <= rightTop.y){
                vec2 tex0 = vec2((vertexPosition.x-leftBottom.x)/(rightTop.x-leftBottom.x),
                     1.0-(vertexPosition.y-leftBottom.y)/(rightTop.y-leftBottom.y));
                vec4 color = texture(topImg, tex0);
                if(0.0 == color.r && 0.0 == color.g && 0.0 == color.b){
                    fragColor = mix(color,texture(img, texturePosition),color.a);
                }else{
                    fragColor = color;
                }
            }else{
                fragColor = texture(img, texturePosition);
            }
        }
    """.trimIndent()

    private var mVboId = 0
    private var mIboId = 0

    override fun runInHandler(f: (() -> Unit)) {
        mHandler.post { f() }
    }

    override fun release() {
        mHandler.post {
            EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
            GLES30.glUseProgram(mProgramId)
            GLES30.glReleaseShaderCompiler()
            EGL14.eglDestroyContext(mEglDisplay, mEglContext)
            EGL14.eglTerminate(mEglDisplay)
        }
    }

    override fun initEgl(f: (glContext: EGLContext) -> Unit) {
        mHandler.post {
            Log.d(TAG, "initEgl $TAG")
            mEglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            val version = IntArray(2)
            EGL14.eglInitialize(mEglDisplay, version, 0, version, 1)
            val attr = intArrayOf(
                EGL14.EGL_RED_SIZE, 8,
                EGL14.EGL_GREEN_SIZE, 8,
                EGL14.EGL_BLUE_SIZE, 8,
                EGL14.EGL_ALPHA_SIZE, 8,
                EGL14.EGL_RENDERABLE_TYPE,
                EGL14.EGL_OPENGL_ES2_BIT or EGLExt.EGL_OPENGL_ES3_BIT_KHR,
                EGL14.EGL_NONE
            )
            val eglConfig = arrayOfNulls<android.opengl.EGLConfig>(1)
            val configNum = IntArray(1)
            EGL14.eglChooseConfig(mEglDisplay, attr, 0, eglConfig, 0, configNum.size, configNum, 0)
            mEglContext = EGL14.eglCreateContext(
                mEglDisplay, eglConfig[0], EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
            )
            mEglSurface = EGL14.eglCreatePbufferSurface(mEglDisplay, eglConfig[0], attr, 0)
            EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
            val vertexId =
                compileShader(GLES30.GL_VERTEX_SHADER, vertexShaderCode)
            val fragmentId =
                compileShader(GLES30.GL_FRAGMENT_SHADER, fragmentShaderCode)
            mProgramId = linkProgram(vertexId, fragmentId)

            GLES30.glUseProgram(mProgramId)
            GLES30.glViewport(0, 0, width, height)
            GLES30.glClearColor(1f, 1f, 1f, 1f)
            mImgLocation = GLES30.glGetUniformLocation(mProgramId, "img")
            mTopImgLocation = GLES30.glGetUniformLocation(mProgramId, "topImg")
            mMatrixLocation = GLES30.glGetUniformLocation(mProgramId, "matrix")
            mPositionLocation = GLES30.glGetAttribLocation(mProgramId, "position")
            mTexturePositionLocation = GLES30.glGetAttribLocation(mProgramId, "texturePositionIn")
            LogPrint.Info(
                TAG,
                "mImgLocation=$mImgLocation mTopImgLocation=$mTopImgLocation mMatrixLocation=$mMatrixLocation mPositionLocation=$mPositionLocation mTexturePositionLocation=$mTexturePositionLocation"
            )
            Matrix.orthoM(mMatrixArray, 0, -1f, 1f, -1f, 1f, -1f, 1f)
            val buffer = IntArray(2)
            GLES30.glGenBuffers(buffer.size, buffer, 0)
            mVboId = buffer[0]
            mIboId = buffer[1]

            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mVboId)
            GLES30.glBufferData(
                GLES30.GL_ARRAY_BUFFER,
                mVertexTextureBuffer.capacity() * 4,
                mVertexTextureBuffer.position(0),
                GLES30.GL_STATIC_DRAW
            )
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)

            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, mIboId)
            GLES30.glBufferData(
                GLES30.GL_ELEMENT_ARRAY_BUFFER,
                mIndexBuffer.capacity() * 4,
                mIndexBuffer, GLES30.GL_STATIC_DRAW
            )
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)

            mImgTextureId = loadTexture()

            val sharedTextures = IntArray(1)
            GLES30.glGenTextures(sharedTextures.size, sharedTextures, 0)
            mOutputTextureId = sharedTextures[0]
            val frameBuffers = IntArray(1)
            GLES30.glGenFramebuffers(frameBuffers.size, frameBuffers, 0)
            mFrameBufferId = frameBuffers[0]
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, mFrameBufferId)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mOutputTextureId)
            GLES30.glTexParameteri(
                GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR
            )
            GLES30.glTexParameteri(
                GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR
            )
            GLES30.glTexParameteri(
                GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE
            )
            GLES30.glTexParameteri(
                GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE
            )
            GLES30.glTexImage2D(
                GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, width, height,
                0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null
            )
            GLES30.glFramebufferTexture2D(
                GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0,
                GLES30.GL_TEXTURE_2D, mOutputTextureId, 0
            )
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glUseProgram(0)
            mEglContext?.let { f(it) }
        }
    }

    override fun createSv(f: ((st: SurfaceTexture) -> Unit)) {
        mHandler.post {
            Log.d(TAG, "createSv")
            EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
            GLES30.glUseProgram(mProgramId)
            mImgTextureId = loadOESTexture()
            GLES30.glUseProgram(0)
            f.invoke(SurfaceTexture(mImgTextureId).also { mImgSurfaceTexture = it })
        }
    }

    override fun close() {
        mHandlerThread.quitSafely()
    }

    override fun updateTopImg(bitmap: Bitmap) {
        mHandler.post {
            EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
            GLES30.glUseProgram(mProgramId)
            updateTexture(mTopImgTextureId, bitmap)
            GLES30.glUseProgram(0)
        }
    }

    override fun draw(f: ((tid: Int) -> Unit)?) {
        mHandler.post {
            EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
            GLES30.glUseProgram(mProgramId)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
            try {
                mImgSurfaceTexture?.updateTexImage()
            } catch (e: Exception) {
                LogPrint.Err(TAG, "updateTexImage err")
            }
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, mFrameBufferId)
            GLES30.glUniformMatrix4fv(mMatrixLocation, 1, false, mMatrixArray, 0)
            GLES30.glEnableVertexAttribArray(mPositionLocation)
            GLES30.glEnableVertexAttribArray(mTexturePositionLocation)
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mVboId)
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, mIboId)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, mImgTextureId)
            GLES30.glUniform1i(mImgLocation, 0)
            GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, mTopImgTextureId)
            GLES30.glUniform1i(mTopImgLocation, 1)
            GLES30.glVertexAttribPointer(
                mPositionLocation, 2, GLES30.GL_FLOAT, false, 16, 0
            )
            GLES30.glVertexAttribPointer(
                mTexturePositionLocation, 2, GLES30.GL_FLOAT, false, 16, 8
            )
            GLES30.glDrawElements(
                GLES30.GL_TRIANGLES, mIndexArray.size, GLES30.GL_UNSIGNED_INT, 0
            )
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
            GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, 0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
            GLES30.glDisableVertexAttribArray(mPositionLocation)
            GLES30.glDisableVertexAttribArray(mTexturePositionLocation)
            GLES30.glUseProgram(0)
            f?.invoke(mOutputTextureId)
        }
    }

}