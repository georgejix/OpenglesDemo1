package com.dftc.dvrservice.render

import android.opengl.EGL14
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.util.Log
import android.view.Surface
import com.dftc.dvrservice.LogPrint
import com.dftc.dvrservice.camera.compileShader
import com.dftc.dvrservice.camera.linkProgram
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer

class DvrPreviewRender(val renderName: String):PreviewRender {
    private val TAG: String = "${javaClass.simpleName}$renderName"
    private var mEglDisplay: EGLDisplay? = null
    private var mEglContext: EGLContext? = null
    private var mEglSurface: EGLSurface? = null
    private val mVertexTextureArray = floatArrayOf(
        -1f, -1f, 0f, 0f,
        -1f, 1f, 0f, 1f,
        1f, 1f, 1f, 1f,
        1f, -1f, 1f, 0f
    )

    private val mIndexArray = intArrayOf(0, 1, 2, 0, 2, 3)
    private val mVertexTextureBuffer: FloatBuffer by lazy {
        ByteBuffer.allocateDirect(mVertexTextureArray.size * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().also {
                it.put(mVertexTextureArray).position(0)
            }
    }
    private val mIndexBuffer: IntBuffer by lazy {
        ByteBuffer.allocateDirect(mIndexArray.size * 4)
            .order(ByteOrder.nativeOrder()).asIntBuffer().also {
                it.put(mIndexArray).position(0)
            }
    }
    private var mProgramId = 0
    private var mPositionLocation = 0
    private var mTexturePositionLocation = 1
    private var mImgLocation = 0

    private val vertexShaderCode = """
        #version 300 es
        in vec4 position;
        in vec2 texturePositionIn;
        out vec2 texturePosition;
        void main() {
            gl_Position = position;
            texturePosition = texturePositionIn;
        }
    """.trimIndent()
    private val fragmentShaderCode = """
        #version 300 es
        #extension GL_OES_EGL_image_external_essl3 : require
        precision mediump float;
        uniform sampler2D img;
        in vec2 texturePosition;
        out vec4 fragColor;
        void main() {
            fragColor = texture(img, texturePosition);
        }
    """.trimIndent()

    private var mVboId = 0
    private var mIboId = 0

    override fun release() {
        EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
        GLES30.glUseProgram(mProgramId)
        GLES30.glReleaseShaderCompiler()
        EGL14.eglDestroyContext(mEglDisplay, mEglContext)
        EGL14.eglTerminate(mEglDisplay)
    }

    override fun initEgl(sv: Surface, sharedContext: EGLContext) {
        Log.d(TAG, "initEgl $TAG")
        mEglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val version = IntArray(2)
        EGL14.eglInitialize(mEglDisplay, version, 0, version, 1)
        val attr = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE,
            EGL14.EGL_OPENGL_ES2_BIT or EGLExt.EGL_OPENGL_ES3_BIT_KHR,
            EGL14.EGL_NONE
        )
        val eglConfig = arrayOfNulls<android.opengl.EGLConfig>(1)
        val configNum = IntArray(1)
        EGL14.eglChooseConfig(mEglDisplay, attr, 0, eglConfig, 0, configNum.size, configNum, 0)
        mEglContext = EGL14.eglCreateContext(
            mEglDisplay, eglConfig[0], sharedContext,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0
        )
        mEglSurface = EGL14.eglCreateWindowSurface(
            mEglDisplay, eglConfig[0], sv, intArrayOf(EGL14.EGL_NONE), 0
        )

        EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
        val vertexId =
            compileShader(GLES30.GL_VERTEX_SHADER, vertexShaderCode)
        val fragmentId =
            compileShader(GLES30.GL_FRAGMENT_SHADER, fragmentShaderCode)
        mProgramId = linkProgram(vertexId, fragmentId)

        GLES30.glUseProgram(mProgramId)
        GLES30.glClearColor(1f, 1f, 1f, 1f)
        mImgLocation = GLES30.glGetUniformLocation(mProgramId, "img")
        mPositionLocation = GLES30.glGetAttribLocation(mProgramId, "position")
        mTexturePositionLocation = GLES30.glGetAttribLocation(mProgramId, "texturePositionIn")
        LogPrint.Info(
            TAG,
            "mImgLocation=$mImgLocation mPositionLocation=$mPositionLocation mTexturePositionLocation=$mTexturePositionLocation"
        )
        val buffer = IntArray(2)
        GLES30.glGenBuffers(buffer.size, buffer, 0)
        mVboId = buffer[0]
        mIboId = buffer[1]

        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mVboId)
        GLES30.glBufferData(
            GLES30.GL_ARRAY_BUFFER,
            mVertexTextureBuffer.capacity() * 4,
            mVertexTextureBuffer.position(0),
            GLES30.GL_STATIC_DRAW
        )
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)

        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, mIboId)
        GLES30.glBufferData(
            GLES30.GL_ELEMENT_ARRAY_BUFFER,
            mIndexBuffer.capacity() * 4,
            mIndexBuffer, GLES30.GL_STATIC_DRAW
        )
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES30.glUseProgram(0)
    }

    override fun changeView(w: Int, h: Int) {
        Log.d(TAG, "changeView")
        EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
        GLES30.glUseProgram(mProgramId)
        GLES30.glViewport(0, 0, w, h)
        GLES30.glUseProgram(0)
    }

    override fun draw(textureId: Int) {
        EGL14.eglMakeCurrent(mEglDisplay, mEglSurface, mEglSurface, mEglContext)
        GLES30.glUseProgram(mProgramId)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        GLES30.glEnableVertexAttribArray(mPositionLocation)
        GLES30.glEnableVertexAttribArray(mTexturePositionLocation)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, mVboId)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, mIboId)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE2)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glUniform1i(mImgLocation, 2)
        GLES30.glVertexAttribPointer(
            mPositionLocation, 2, GLES30.GL_FLOAT, false, 16, 0
        )
        GLES30.glVertexAttribPointer(
            mTexturePositionLocation, 2, GLES30.GL_FLOAT, false, 16, 8
        )
        GLES30.glDrawElements(
            GLES30.GL_TRIANGLES, mIndexArray.size, GLES30.GL_UNSIGNED_INT, 0
        )
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, 0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, 0)
        GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, 0)
        GLES30.glDisableVertexAttribArray(mPositionLocation)
        GLES30.glDisableVertexAttribArray(mTexturePositionLocation)
        EGL14.eglSwapBuffers(mEglDisplay, mEglSurface)
        GLES30.glUseProgram(0)
    }
}