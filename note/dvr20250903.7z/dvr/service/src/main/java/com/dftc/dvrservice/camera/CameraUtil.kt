package com.dftc.dvrservice.camera

import android.annotation.SuppressLint
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCaptureSession.CaptureCallback
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import com.dftc.dvrservice.LogPrint
import com.dftc.dvrservice.bean.CameraBean
import com.dftc.dvrservice.render.DvrCodecRender
import com.dftc.dvrservice.render.DvrCombineRender
import com.dftc.dvrservice.render.DvrPreviewRender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

object CameraUtil {
    private val TAG = javaClass.simpleName
    var mCameraManager: CameraManager? = null
    private val mBachHandlerThread by lazy { HandlerThread("camera_thread") }
    private val mBackHandler by lazy {
        mBachHandlerThread.start()
        Handler(mBachHandlerThread.looper)
    }
    private val mWaterMarkUtil by lazy { WaterMarkUtil() }
    val mDvrCameraBean: CameraBean by lazy { CameraBean(1920, 1080, "3") }
    private var mWaterMarkJob: Job? = null
    private var mNeedWaterMark = true

    fun release() {
        cancelWaterMarkJob()
        release(mDvrCameraBean)
        mCameraManager = null
        mBachHandlerThread.quitSafely()
    }

    private fun release(cameraBean: CameraBean) {
        with(cameraBean) {
            mCombineRender?.runInHandler {
                mCameraCaptureSession?.stopRepeating()
                mCameraDevice?.close()
                closeCameraPreview(this)
                mCodecRender?.release()
                mCodecRender = null
                mRecordUtil?.release()
                mRecordUtil = null
                mCombineRender?.release()
                mCombineRender = null
            }
        }
    }

    private fun checkCamera() {

    }

    @SuppressLint("MissingPermission")
    fun initCamera() {
        listOf(mDvrCameraBean).forEach { cameraBean ->
            DvrCombineRender(
                "combine${cameraBean.mCameraId}", cameraBean.mWidth, cameraBean.mHeight
            ).let { combineRender ->
                cameraBean.mCombineRender = combineRender
                combineRender.initEgl { eglContext ->
                    genWaterMarkJob()
                    runCatching {
                        val record =
                            RecordUtil(cameraBean.mCameraId, cameraBean.mWidth, cameraBean.mHeight)
                        record.start()
                        val dvrCodecRender = DvrCodecRender(
                            "codec${cameraBean.mCameraId}", cameraBean.mWidth, cameraBean.mHeight
                        )
                        record.getSurface()?.let { surface ->
                            dvrCodecRender.initEgl(surface, eglContext)
                            cameraBean.mCodecRender = dvrCodecRender
                        }
                        cameraBean.mRecordUtil = record
                    }
                }
                combineRender.createSv { st ->
                    st.setOnFrameAvailableListener {
                        combineRender.draw { sharedId ->
                            cameraBean.mCodecRender?.draw(sharedId)
                            cameraBean.mPreviewRender?.draw(sharedId)
                        }
                    }
                    val surface2 = Surface(st)
                    runCatching {
                        mCameraManager?.openCamera(
                            cameraBean.mCameraId, object : CameraDevice.StateCallback() {
                                override fun onOpened(camera: CameraDevice) {
                                    cameraBean.mCameraDevice = camera
                                    createSession(surface2, camera, cameraBean)
                                }

                                override fun onDisconnected(camera: CameraDevice) {
                                    runCatching { camera.close() }
                                    cameraBean.mCameraDevice = null
                                }

                                override fun onError(camera: CameraDevice, error: Int) {
                                    runCatching { camera.close() }
                                    cameraBean.mCameraDevice = null
                                }
                            }, mBackHandler
                        )
                    }
                }
            }
        }
    }

    fun addPreview(surface: Surface, cameraBean: CameraBean) {
        cameraBean.mCombineRender?.runInHandler {
            cameraBean.mCombineRender?.mEglContext?.let { c ->
                DvrPreviewRender(("preview${cameraBean.mCameraId}")).also { render ->
                    render.initEgl(surface, c)
                    cameraBean.mPreviewRender = render
                }
            }
        }
    }

    fun changePreviewView(cameraBean: CameraBean, width: Int, height: Int) {
        cameraBean.mCombineRender?.runInHandler {
            cameraBean.mPreviewRender?.changeView(width, height)
        }
    }

    fun closeCameraPreview(cameraBean: CameraBean) {
        cameraBean.mPreviewRender?.release()
        cameraBean.mPreviewRender = null
    }

    private fun createSession(surface: Surface, camera: CameraDevice, cameraBean: CameraBean) {
        camera.createCaptureSession(
            SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR,
                listOf(OutputConfiguration(1, surface)),
                Executors.newCachedThreadPool(),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        LogPrint.Debug(TAG, "createSession.onConfigured")
                        cameraBean.mCameraCaptureSession = session
                        createRepeatingRequest(surface, camera, session)
                    }

                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        LogPrint.Err(TAG, "createSession.onConfigureFailed")
                        cameraBean.mCameraCaptureSession = null
                        runCatching {
                            session.stopRepeating()
                            session.abortCaptures()
                            session.close()
                        }
                    }
                })
        )
    }

    private fun createRepeatingRequest(
        surface: Surface, camera: CameraDevice, session: CameraCaptureSession
    ) {
        session.setRepeatingRequest(
            camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).also {
                it.addTarget(surface)
            }.build(), object : CaptureCallback() {
                override fun onCaptureStarted(
                    session: CameraCaptureSession, request: CaptureRequest,
                    timestamp: Long, frameNumber: Long
                ) {
                }

                override fun onCaptureFailed(
                    session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure
                ) {
                    LogPrint.Err(TAG, "createRepeatingRequest.onCaptureFailed")
                    cancelWaterMarkJob()
                    session.stopRepeating()
                }
            }, mBackHandler
        )
    }

    private fun genWaterMarkJob() {
        mWaterMarkJob?.let { return }
        mWaterMarkJob = CoroutineScope(Dispatchers.IO).launch {
            while (mNeedWaterMark) {
                listOf(mDvrCameraBean.mCombineRender).filterNotNull().forEach { render ->
                    render.updateTopImg(mWaterMarkUtil.genCarInfoBitmap())
                    delay(1000)
                }
            }
        }
    }

    private fun cancelWaterMarkJob() {
        mWaterMarkJob?.cancel()
        mWaterMarkJob = null
    }
}