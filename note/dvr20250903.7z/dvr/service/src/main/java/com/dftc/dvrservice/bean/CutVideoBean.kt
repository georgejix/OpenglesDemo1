package com.dftc.dvrservice.bean

data class CutVideoBean(val startTime: Long, val endTime: Long)