package com.dftc.dvrservice

import android.app.Application
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import com.dftc.dvrservice.camera.CameraUtil

class DvrServiceApplication : Application() {
    private val TAG = javaClass.simpleName

    companion object {
        var mApplicationContext: Context? = null
        fun getOutputVideoPath(name: String): String {
            return mApplicationContext?.let {
                "${it.getExternalFilesDir("video")}/$name.mp4"
            } ?: ""
        }
    }

    override fun onCreate() {
        super.onCreate()
        LogPrint.Info(TAG, "onCreate")
        mApplicationContext = this
        CameraUtil.mCameraManager = getSystemService(CameraManager::class.java)
        CameraUtil.initCamera()
        startService(Intent(this, DvrPreviewService::class.java))
    }

    override fun onTerminate() {
        super.onTerminate()
        mApplicationContext = null
        CameraUtil.release()
    }
}