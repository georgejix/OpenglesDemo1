package com.dftc.dvrservice.bean

import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import com.dftc.dvrservice.camera.RecordUtil
import com.dftc.dvrservice.render.CodecRender
import com.dftc.dvrservice.render.CombineRender
import com.dftc.dvrservice.render.PreviewRender

data class CameraBean(
    var mWidth: Int,
    var mHeight: Int,
    var mCameraId: String,
    var mCameraDevice: CameraDevice? = null,
    var mCameraCaptureSession: CameraCaptureSession? = null,
    var mRecordUtil: RecordUtil? = null,
    var mCombineRender: CombineRender? = null,
    var mPreviewRender: PreviewRender? = null,
    var mCodecRender: CodecRender? = null
)