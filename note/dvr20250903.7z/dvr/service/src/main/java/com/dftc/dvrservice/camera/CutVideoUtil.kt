package com.dftc.dvrservice.camera

import android.annotation.SuppressLint
import android.media.MediaCodec.BufferInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import com.dftc.dvrservice.DvrServiceApplication
import com.dftc.dvrservice.LogPrint
import com.dftc.dvrservice.bean.CutVideoBean
import com.dftc.dvrservice.bean.VideoBean
import java.nio.ByteBuffer
import java.text.SimpleDateFormat

class CutVideoUtil {
    private val TAG = javaClass.simpleName
    private val mSdf by lazy { SimpleDateFormat("yyyy-MM-dd-HH-mm-ss") }

    @SuppressLint("WrongConstant")
    fun cut(list: ArrayList<VideoBean>, cutBean: CutVideoBean) {
        val cutFile =
            DvrServiceApplication.getOutputVideoPath("cut_${mSdf.format(System.currentTimeMillis())}")
        val muxer = MediaMuxer(cutFile, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var toVideoTrackIndex = -1
        var needDuration = cutBean.endTime - cutBean.startTime
        var totalDuration = 0L
        list.sortWith { v1, v2 -> if (v1.startTime > v2.startTime) 1 else -1 }
        list.forEach { videoBean ->
            val extractor = MediaExtractor().also { it.setDataSource(videoBean.path) }
            repeat(extractor.trackCount) { trackIndex ->
                if (true == extractor.getTrackFormat(trackIndex).getString(MediaFormat.KEY_MIME)
                        ?.contains("video/")
                ) {
                    extractor.selectTrack(trackIndex)
                    if (toVideoTrackIndex < 0) {
                        toVideoTrackIndex = muxer.addTrack(extractor.getTrackFormat(trackIndex))
                        muxer.start()
                    }
                }
            }
            val bufferInfo = BufferInfo()
            val data = ByteBuffer.allocate(1920 * 1080)
            var sampleTime = 0L

            // 调整 extractor 的时间偏移量
            if (videoBean.startTime < cutBean.startTime) {
                extractor.seekTo(
                    (cutBean.startTime - videoBean.startTime) * 1000,
                    MediaExtractor.SEEK_TO_CLOSEST_SYNC
                )
            } else {
                extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            }

            while (true) {
                var readSize = extractor.readSampleData(data, 0)
                if (readSize < 0) break
                sampleTime = extractor.sampleTime
                bufferInfo.presentationTimeUs = sampleTime + totalDuration
                bufferInfo.flags = extractor.sampleFlags
                bufferInfo.size = readSize
                muxer.writeSampleData(toVideoTrackIndex, data, bufferInfo)
                extractor.advance()
                if (needDuration * 1000 <= sampleTime + totalDuration) break
            }
            totalDuration += (sampleTime + 1)
            extractor.release()
        }
        muxer.stop()
        muxer.release()
        LogPrint.Info(TAG, "cut $cutFile end")
    }
}