plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.kapt")
}

android {
    signingConfigs {
        getByName("debug") {
            storeFile = file("../platform.jks")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
        create("release") {
            storeFile = file("../platform.jks")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    namespace = "com.dftc.dvr"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.dftc.dvr"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        dataBinding = true
        viewBinding = true
    }
    dataBinding {
        true
    }
    afterEvaluate {
        applicationVariants.all { variant ->
            val outputFile = variant.outputs.first().outputFile
            tasks.named("assemble${variant.name.capitalize()}") {
                doLast {
                    copy {
                        from(outputFile)
                        into("../apk/")
                        rename(outputFile.name, "DFDVR-${variant.name.capitalize()}.apk")
                    }
                }
            }
            true
        }
    }
}

dependencies {
    implementation(fileTree(mapOf("dir" to "libs", "include" to listOf("*.jar", "*.aar"))))
    implementation("androidx.appcompat:appcompat:1.3.1")
    implementation("androidx.activity:activity-compose:1.7.0")
    implementation("androidx.fragment:fragment-ktx:1.5.0")
    implementation("androidx.recyclerview:recyclerview:1.0.0")
    implementation("androidx.viewpager2:viewpager2:1.0.0")
    implementation("androidx.constraintlayout:constraintlayout:2.0.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("com.tencent:mmkv:1.2.10")

    implementation("androidx.room:room-runtime:2.4.2")// 请检查最新版本
    kapt("androidx.room:room-compiler:2.4.2") // 请检查最新版本
    implementation("androidx.sqlite:sqlite-framework:2.2.0") // 请检查最新版本


    implementation(files("libs\\nesitnext.extbroker.jar"))
}