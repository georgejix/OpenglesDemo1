package com.dftc.dvr.adapter

import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.RecyclerView

/**
 * @author: ZJZ
 * @date: 2025/8/28
 * @description：
 */
class  GridSpacingDecoration(private val spanCount: Int, private val spacingH: Int, private val spacingV: Int) : RecyclerView.ItemDecoration() {

    override fun getItemOffsets(outRect: Rect, view: View, parent: RecyclerView, state: RecyclerView.State) {
        val position = parent.getChildAdapterPosition(view)
        val column = position % spanCount

        outRect.left = column * spacingH / spanCount
        outRect.right = spacingH - (column + 1) * spacingH / spanCount
        if (position >= spanCount) outRect.top = spacingV

//        // 行间距
//        if(position < spanCount) outRect.top = spacing
//        if(position >= parent.getAdapter().getItemCount() - spanCount) {
//            outRect.bottom = spacing
//        } else {
//            outRect.top = spacing
//        }
    }
}