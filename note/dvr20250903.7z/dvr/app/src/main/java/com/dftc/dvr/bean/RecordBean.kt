package com.dftc.dvr.bean

/**
 * @author: ZJZ
 * @date: 2025/8/20
 * @description：
 */
data class RecordBean(var name : String = "name", var duration : Int = 100, var filePath : String = "", var isChecked : Boolean = false, var isHeader : Boolean = false, var headerText : String ="")
