package com.dftc.dvr.constants

/**
 * @author: ZJZ
 * @date: 2025/8/25
 * @description：
 */
object MMKVKeyConstant {
    const val KEY_LOOP_RECORD = "KEY_LOOP_RECORD"
    const val KEY_LOOP_RECORD_TIME = "KEY_LOOP_RECORD_TIME"
    const val KEY_DRIVE_INFO = "KEY_DRIVE_INFO"
    const val KEY_RECORD_VOICE = "KEY_RECORD_VOICE"
    const val KEY_RECORD_PERSPECTIVE = "KEY_RECORD_PERSPECTIVE"
    const val KEY_SENTRY_MODE = "KEY_SENTRY_MODE"
    const val KEY_SENTRY_MODE_HOME = "KEY_SENTRY_MODE_HOME"
    const val KEY_SENTRY_MODE_COMPANY = "KEY_SENTRY_MODE_COMPANY"
    const val KEY_SENTRY_MODE_COLLECT = "KEY_SENTRY_MODE_COLLECT"
}