package com.dftc.dvr.widget

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.dftc.dvr.R

/**
 * @author: ZJZ
 * @date: 2023/11/3
 * @description：
 */
class DropDownLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {
    val TAG = javaClass::class.java.simpleName
    private lateinit var mIvStatus: ImageView
    private lateinit var mTvContent: TextView
    private lateinit var mLyRoot: LinearLayout
    private var CURRENT_STATUS = STATUS_CLOSE
    private val text: String? // 默认显示文字
    companion object {
        const val STATUS_CLOSE = 1 //默认关闭状态，未赋值
        const val STATUS_OPEN = 2 //打开状态
        const val STATUS_CHANGE = 3 // 赋值状态，页面显示具体值，和X图标
    }


    init {
        val array = context.obtainStyledAttributes(attrs, R.styleable.check_style)
        text = array.getString(R.styleable.check_style_text)
        init(context)
    }

    private fun init(context: Context?) {
        val view = LayoutInflater.from(context).inflate(R.layout.layout_drop_down, this)
        mLyRoot = view.findViewById(R.id.ly_root)
        mIvStatus = view.findViewById(R.id.iv_status)
        mTvContent = view.findViewById(R.id.tv_content)

        text?.let {
            mTvContent.text = text
        }
        mLyRoot.setOnClickListener { v ->
            changeStatus()
        }
    }

    private fun changeStatus() {
        mCallback?.let {
            when(CURRENT_STATUS) {
                STATUS_CLOSE -> {
                    Log.i(TAG,"changeStatus --- > STATUS_CLOSE")
                    CURRENT_STATUS = STATUS_OPEN
                    it.openMenu()
                    mIvStatus.setBackgroundResource(R.drawable.selector_drop_down_open)
                }
                STATUS_OPEN -> {
                    Log.i(TAG,"changeStatus --- > STATUS_OPEN")
                    CURRENT_STATUS = STATUS_CLOSE
                    it.closeMenu()
                    mIvStatus.setBackgroundResource(R.drawable.selector_drop_down_close)
                }
                STATUS_CHANGE -> {
                    Log.i(TAG,"changeStatus --- > STATUS_CHANGE")
                    CURRENT_STATUS = STATUS_CLOSE
                    it.clearMenu()
                    mTvContent.text = text
                    mIvStatus.setBackgroundResource(R.drawable.selector_icon_general_close)
                }
            }
        }
    }

    fun setContent(content : String) {
        CURRENT_STATUS = STATUS_CHANGE
        mTvContent.text = content
        mIvStatus.setBackgroundResource(R.mipmap.drop_down_delete)
    }

    private var mCallback : DropDownCallback ?= null
    fun setCheckedCallback(callback: DropDownCallback) {
        mCallback = callback
    }

    interface DropDownCallback {
        fun openMenu()
        fun closeMenu()

        fun clearMenu()
    }
}