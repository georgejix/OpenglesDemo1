package com.dftc.dvr.widget

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import androidx.annotation.StyleRes

/**
 * @author: ZJZ
 * @date: 2025/8/18
 * @description：
 */
class PopupBuilder(private val context: Context) {
    // 配置参数存储
    private var contentView: View? = null
    private var width = ViewGroup.LayoutParams.WRAP_CONTENT
    private var height = ViewGroup.LayoutParams.WRAP_CONTENT
    private var animationStyle: Int = 0
    private var isOutsideTouchable = true
    private var onDismissListener: (() -> Unit)? = null

    // 构建方法
    fun build(): PopupWindow {
        Log.i("DrivingRecordFragment", "build --- 1")
        requireNotNull(contentView) { "ContentView must be set" }
        return PopupWindow(contentView, width, height).apply {
            isFocusable = true
            isOutsideTouchable = this@PopupBuilder.isOutsideTouchable
            setOnDismissListener { onDismissListener?.invoke() }
            Log.i("DrivingRecordFragment", "build --- 2")
            if (animationStyle != 0) animationStyle = this@PopupBuilder.animationStyle
        }
    }

    // 链式配置方法
    fun setContentView(layoutId: Int) = apply {
        contentView = LayoutInflater.from(context).inflate(layoutId, null)
    }

    fun setCustomView(view: View) = apply {
        contentView = view
    }

    fun setWidth(width: Int) = apply {
        this.width = width
    }

    fun setHeight(height: Int) = apply {
        this.height = height
    }


    fun setFullWidth() = apply {
        this.width = context.resources.displayMetrics.widthPixels
    }

    fun setAnimation(@StyleRes resId: Int) = apply {
        animationStyle = resId
    }
}