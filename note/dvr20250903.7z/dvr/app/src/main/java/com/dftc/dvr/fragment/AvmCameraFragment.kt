package com.dftc.dvr.fragment

import com.dftc.dvr.DvrViewModel
import com.dftc.dvr.R
import com.dftc.dvr.databinding.FragmentAvmCameraBinding

class AvmCameraFragment : BaseFragment<FragmentAvmCameraBinding>() {
    override var TAG = javaClass.simpleName

    companion object {
        val INTENT_CAMERA_ID = "id"
    }

    override fun getLayoutId(): Int = R.layout.fragment_avm_camera

    override fun onCreateView() {
        mBinding?.globalVm = DvrViewModel
        addSurfaceViewListener()
    }

    override fun initView() {

    }

    override fun addListener() {

    }

    private fun getCameraId(): String? = arguments?.getString(INTENT_CAMERA_ID)

    private fun addSurfaceViewListener() {
    }
}