package com.dftc.dvr.db.bean

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * @author: ZJZ
 * @date: 2025/8/26
 * @description：
 */
@Entity
data class RecordInfo(
    @PrimaryKey(autoGenerate = true) val id : Int = 0,
    val fileName : String,
    val address : String,
    var recordDate : String,
    var recordTime : Long,
    var mainPath : String)