package com.dftc.dvr.adapter

import android.content.ClipData.Item
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.loader.content.Loader
import androidx.recyclerview.widget.RecyclerView
import com.dftc.dvr.R
import com.dftc.dvr.bean.RecordBean
import com.dftc.dvr.databinding.ItemLayoutDrivingRecordBinding
import com.dftc.dvr.databinding.ItemLayoutDrivingRecordHeaderBinding
import com.dftc.dvr.databinding.ItemLayoutLocationBinding

/**
 * @author: ZJZ
 * @date: 2025/8/18
 * @description：
 */
class DrivingRecordAdapter(private val context: Context, private var groupedData: List<RecordBean>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    companion object {
        const val TYPE_DATE_HEADER = 0
        private const val TYPE_CONTENT_ITEM = 1
        private const val TAG = "DrivingRecordAdapter"
    }

    private var EDIT_STATUS = false

    fun setEditStatus(status : Boolean) {
        Log.i(TAG,"setEditStatus --- > status : $status")
        EDIT_STATUS = status
        notifyDataSetChanged()
    }


    override fun getItemViewType(position: Int): Int {
        return if (groupedData[position].isHeader) {
            TYPE_DATE_HEADER
        } else {
            TYPE_CONTENT_ITEM
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            TYPE_DATE_HEADER -> {
                val binding = ItemLayoutDrivingRecordHeaderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                HeaderViewHolder(binding)
            }
            else -> {
                val binding = ItemLayoutDrivingRecordBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                RecordItemHolder(binding)
            }
        }
    }

    override fun getItemCount(): Int = groupedData.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is HeaderViewHolder) {
            holder.bind(groupedData[position])
        } else if (holder is RecordItemHolder) {
            holder.bind(groupedData[position], EDIT_STATUS)
        }

    }

    class RecordItemHolder(private val binding: ItemLayoutDrivingRecordBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: RecordBean, status: Boolean) {
            binding.tvTime.text = item.name
            if (status) {
                binding.cbEdit.visibility = View.VISIBLE
            } else {
                binding.cbEdit.visibility = View.GONE
            }
        }
    }

    class HeaderViewHolder(private val binding: ItemLayoutDrivingRecordHeaderBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: RecordBean) {
            binding.tvLocation.text = item.headerText
            binding.tvLocation.isSelected = true
        }
    }
}