package com.dftc.dvr.adapter

import android.content.ClipData.Item
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dftc.dvr.databinding.ItemLayoutLocationBinding

/**
 * @author: ZJZ
 * @date: 2025/8/18
 * @description：
 */
class PopLocationAdapter(val context: Context, var list: List<String>) : RecyclerView.Adapter<PopLocationAdapter.PopLocationHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PopLocationHolder {
        val binding = ItemLayoutLocationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PopLocationHolder(binding)
    }

    override fun getItemCount(): Int = list.size

    override fun onBindViewHolder(holder: PopLocationHolder, position: Int) {
        holder.bind(list[position])

        holder.itemView.setOnClickListener {

        }

    }

    class PopLocationHolder(private val binding: ItemLayoutLocationBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: String) {
            binding.tvLocation.text = item
            binding.tvLocation.isSelected = true
        }
    }
}