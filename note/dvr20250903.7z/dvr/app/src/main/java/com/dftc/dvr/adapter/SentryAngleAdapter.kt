package com.dftc.dvr.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.dftc.dvr.bean.SentryAngleBean
import com.dftc.dvr.bean.SentryAngleEnum
import com.dftc.dvr.databinding.ItemSentryAngleBinding

class SentryAngleAdapter(
    private val context: Context, private var data: List<SentryAngleBean>,
    val mListener: ((item: SentryAngleBean) -> Unit)
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    companion object {
        private const val TAG = "SentryAngleAdapter"
    }

    private var mSelectedType: SentryAngleEnum = SentryAngleEnum.FRONT

    fun getSelectedType() = mSelectedType

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding =
            ItemSentryAngleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SentryAngleItemHolder(binding)
    }

    override fun getItemCount(): Int = data.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is SentryAngleItemHolder) {
            data[position].let { bean ->
                holder.itemView.isSelected = mSelectedType == bean.type

                holder.itemView.setOnClickListener {
                    mSelectedType = bean.type
                    notifyDataSetChanged()
                    mListener.invoke(bean)
                }
            }
        }
    }


    class SentryAngleItemHolder(private val binding: ItemSentryAngleBinding) :
        RecyclerView.ViewHolder(binding.root)

}