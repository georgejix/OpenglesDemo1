package com.dftc.dvr.util

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import com.dftc.dvr.R
import com.google.android.material.snackbar.Snackbar

/**
 * @author: ZJZ
 * @date: 2025/8/21
 * @description：
 */
object ToastUtil {
    private var toast: Toast? = null

    fun showToast(context: Context, message: String) {
        Handler(Looper.getMainLooper()).post {
//            toast?.cancel()
//            toast = Toast(context).apply {
//                val view = LayoutInflater.from(context).inflate(R.layout.toast_custom, null).apply {
//
//                        findViewById<TextView>(R.id.tv_toast).text = message
//                    }
//                setGravity(Gravity.TOP, 0, 0)
////                view.width = context.resources.displayMetrics.widthPixels
//                setView(view)
//                duration = Toast.LENGTH_SHORT
//                show()
//            }

            val view = LayoutInflater.from(context).inflate(R.layout.toast_custom, null).apply {

                findViewById<TextView>(R.id.tv_toast).text = message
            }
            // 创建基础Snackbar
            Snackbar.make(view, message, Snackbar.LENGTH_LONG).show()
        }
    }

    fun showFullWidthToast(context: Context, message: String) {
        val toast = Toast.makeText(context, "", Toast.LENGTH_LONG)
        val textView = TextView(context).apply {
            text = message
            setTextColor(resources.getColor(R.color.color_1A1A1A_E6E6E6))
            isSingleLine = true
            setBackgroundResource(R.drawable.shape_toast_bg)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(64, 46, 64, 46)
        }
        toast.view = textView
        toast.setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, 0)
        toast.show()
    }
}