package com.dftc.dvr.bean

enum class PlayerStatusEnum {
    COMPLETION,
    ERROR,
    INFO,
    PREPARED,
    SEEK_COMPLETE,
    VIDEO_SIZE
}