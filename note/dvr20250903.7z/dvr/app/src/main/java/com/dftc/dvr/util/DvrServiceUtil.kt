package com.dftc.dvr.util

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.os.IBinder
import android.view.Surface
import com.dftc.dvr.DvrApplication
import com.dftc.dvraidl.DvrAidlConstant
import com.dftc.dvraidl.IDvrData
import com.dftc.dvraidl.IDvrPreview
import com.dftc.dvraidl.bean.RecordInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

object DvrServiceUtil {
    private val TAG = javaClass.simpleName
    private var mDvrPreviewImpl: IDvrPreview? = null
    private var mDvrDataImpl : IDvrData ?= null


    //防止服务绑定太慢，晚于surface创建，缓存3个任务
    private val mWaitFuncQueue = LinkedBlockingQueue<(() -> Unit)>(3)

    fun init() {
        DvrApplication.mApplicationContext?.let { context ->
            LogPrint.Info(TAG, "bindService")
            context.bindService(DvrAidlConstant.dvrPreviewIntent, object : ServiceConnection {
                override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                    LogPrint.Info(TAG, "onServiceConnected")
                    mDvrPreviewImpl = IDvrPreview.Stub.asInterface(service)
                    mDvrDataImpl = IDvrData.Stub.asInterface(service)
                    mWaitFuncQueue.forEach { it.invoke() }
                    mWaitFuncQueue.clear()
                }

                override fun onServiceDisconnected(name: ComponentName?) {
                    LogPrint.Info(TAG, "onServiceDisconnected")
                    mDvrPreviewImpl = null
                    CoroutineScope(Dispatchers.IO).launch {
                        delay(3000)
                        mDvrPreviewImpl ?: init()
                    }
                }

            }, Context.BIND_AUTO_CREATE)
        }
        CoroutineScope(Dispatchers.IO).launch {
            delay(3000)
            mDvrPreviewImpl ?: init()
        }
    }


    fun setPreview(type: Int, surface: Surface) {
        mDvrPreviewImpl?.setPreviewSurface(type, surface) ?: let {
            kotlin.runCatching {
                mWaitFuncQueue.offer(
                    { mDvrPreviewImpl?.setPreviewSurface(type, surface) }, 3, TimeUnit.SECONDS
                )
            }
        }
    }

    fun setPreviewSize(type: Int, width: Int, height: Int) {
        mDvrPreviewImpl?.setPreviewSize(type, width, height) ?: let {
            kotlin.runCatching {
                mWaitFuncQueue.offer(
                    { mDvrPreviewImpl?.setPreviewSize(type, width, height) }, 3, TimeUnit.SECONDS
                )
            }
        }
    }

    fun removePreview(type: Int) {
        mDvrPreviewImpl?.removePreviewSurface(type) ?: let {
            kotlin.runCatching {
                mWaitFuncQueue.offer(
                    { mDvrPreviewImpl?.removePreviewSurface(type) }, 3, TimeUnit.SECONDS
                )
            }
        }
    }



    fun saveSettingDate(key : String, value : Int) {
        mDvrDataImpl?.saveSettingDate(key, value)
    }

    fun getSettingDate(key : String) : Int? = mDvrDataImpl?.getSettingDate(key)

    fun  getRecordInfos(type : Int , date : String, address : String, riskType : Int) : List<RecordInfo>? = mDvrDataImpl?.getRecordInfos(type, date, address, riskType)

    fun deleteRecord(list : List<RecordInfo>) {
        mDvrDataImpl?.deleteRecord(list)
    }
}