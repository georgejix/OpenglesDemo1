package com.dftc.dvr.activity

import android.content.pm.PackageManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentActivity
import androidx.viewbinding.ViewBinding
import com.dftc.dvr.R
import com.dftc.dvr.util.LogPrint

abstract class BaseActivity<T : ViewBinding> : FragmentActivity() {
    open var TAG = javaClass.simpleName
    var mBinding: T? = null
    private var mNeedInitListener = false
    private var mNeedInitView = false

    abstract fun getLayoutId(): Int

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mBinding = DataBindingUtil.setContentView(this, getLayoutId())
        mNeedInitListener = true
        mNeedInitView = true
    }

    override fun onResume() {
        super.onResume()
        if (mNeedInitView) {
            initView()
            mNeedInitView = false
        }
        if (mNeedInitListener) {
            addListener()
            mNeedInitListener = false
        }
    }

    open fun addListener() {}

    open fun initView() {}

    open fun needPermissions(): Array<String> = arrayOf()

    open fun onPermissionCb(get: Boolean) {

    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (1 == requestCode) {
            if (needPermissions().all {
                    LogPrint.Debug(TAG, "$it ${ContextCompat.checkSelfPermission(this, it)}")
                    PackageManager.PERMISSION_GRANTED ==
                            ContextCompat.checkSelfPermission(this, it)
                }) {
                onPermissionCb(true)
            } else {
                LogPrint.Err(TAG, "no permission")
                onPermissionCb(false)
            }
        }
    }
}