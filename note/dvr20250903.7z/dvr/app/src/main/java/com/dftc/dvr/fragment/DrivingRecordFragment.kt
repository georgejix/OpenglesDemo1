package com.dftc.dvr.fragment

import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dftc.dvr.R
import com.dftc.dvr.adapter.DrivingRecordAdapter
import com.dftc.dvr.adapter.PopLocationAdapter
import com.dftc.dvr.bean.RecordBean
import com.dftc.dvr.databinding.FragmentDrivingRecordBinding
import com.dftc.dvr.util.ToastUtil
import com.dftc.dvr.widget.DropDownLayout
import com.dftc.dvr.widget.PopupBuilder
import com.dftc.dvr.widget.RecordLoadingDialog
import com.dftc.dvr.widget.RecordOperationDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

/**
 * @author: ZJZ
 * @date: 2025/8/13
 * @description：
 */
class DrivingRecordFragment : BaseFragment<FragmentDrivingRecordBinding>() {
    private var recordList : ArrayList<RecordBean> = ArrayList()
    override fun getLayoutId(): Int = R.layout.fragment_driving_record

    override fun onCreateView() {
        initAdapter()
    }


    override fun addListener() {
        super.addListener()

        mBinding?.rgRecord?.setOnCheckedChangeListener { group, checkedId ->
            when(checkedId) {
                R.id.rb_record_loop -> showLoopRecord()
                R.id.rb_record_urgent -> showUrgentRecord()
            }
        }

        mBinding?.btnEdit?.setOnClickListener {
            mBinding?.btnCancel?.visibility = View.VISIBLE
            mBinding?.lyEdit?.visibility = View.VISIBLE
            mBinding?.btnEdit?.visibility = View.GONE
            mBinding?.dlDate?.visibility = View.GONE
            mBinding?.dlLocation?.visibility = View.GONE

            mAdapter?.setEditStatus(true)
        }

        mBinding?.btnCancel?.setOnClickListener {
            mBinding?.btnCancel?.visibility = View.GONE
            mBinding?.lyEdit?.visibility = View.GONE
            mBinding?.btnEdit?.visibility = View.VISIBLE
            mBinding?.dlDate?.visibility = View.VISIBLE
            mBinding?.dlLocation?.visibility = View.VISIBLE

            mAdapter?.setEditStatus(false)
        }

        mBinding?.dlDate?.setCheckedCallback(object : DropDownLayout.DropDownCallback {
            override fun openMenu() {
                Log.i(TAG,"openMenu --- >1")
                PopupBuilder(requireContext()).setCustomView(getDateSelectView()).setWidth(748).
                setHeight(612).build().showAtLocation(mBinding?.dlDate, Gravity.CENTER, 15, 40)
                Log.i(TAG,"openMenu --- >2")
            }

            override fun closeMenu() {

            }

            override fun clearMenu() {

            }
        })

        mBinding?.dlLocation?.setCheckedCallback(object : DropDownLayout.DropDownCallback {
            override fun openMenu() {
                Log.i(TAG,"openMenu --- >1")
                PopupBuilder(requireContext()).setCustomView(getLocationView()).setWidth(248).
                setHeight(504).build().showAtLocation(mBinding?.dlLocation, Gravity.CENTER, 60, 0)

                Log.i(TAG,"openMenu --- >")
            }

            override fun closeMenu() {

            }

            override fun clearMenu() {

            }
        })

        mBinding?.tvDelete?.setOnClickListener {
            var funC : () -> Unit = {
                Log.i(TAG,"delete --- > ")
                CoroutineScope(Dispatchers.IO).launch {
                    var deleteList = recordList?.filter { it.isChecked }?.forEach { r ->
                        var file = File(r.filePath)

                        file?.let { f ->
                            if (f.exists() && f.isFile) {
                                f.delete()
                            }
                        }

                    }
                }

                RecordLoadingDialog.Builder(requireContext()).build().show()
            }
            RecordOperationDialog.Builder(requireContext()).setTip("是否要删除12个文件？").setPositiveButton(funC).build().show()
        }



        mBinding?.tvImport?.setOnClickListener {
            checkImport()
        }
    }


    private fun checkImport() {
        if (true) {
            ToastUtil.showFullWidthToast(requireContext().applicationContext, "已导出文件至U盘")
//            RecordExceptionDialog.Builder(requireContext()).setTip("未检测到U盘插入，请检查U盘插入后重试").build().show()

            return
        }

        var funC : () -> Unit = {
            Log.i(TAG,"Import --- > ")
            CoroutineScope(Dispatchers.IO).launch {
                var deleteList = recordList?.filter { it.isChecked }?.forEach { r ->
                    var file = File(r.filePath)

                    file?.let { f ->
                        if (f.exists() && f.isFile) {
                            f.delete()
                        }
                    }

                }
            }
        }

        RecordOperationDialog.Builder(requireContext()).setTip("是否要导出选中的8个文件?").setPositiveButton(funC).build().show()
    }

    private fun showLoopRecord() {
        mBinding?.vLine1?.visibility = View.VISIBLE
        mBinding?.vLine2?.visibility = View.INVISIBLE
    }

    private fun showUrgentRecord() {
        mBinding?.vLine1?.visibility = View.INVISIBLE
        mBinding?.vLine2?.visibility = View.VISIBLE
    }


    fun getLocationView() : View {
        Log.i(TAG,"getLocationView --- >1")
        var list = listOf<String>("北京","上海","南京","苏州","天津","无锡","常州","镇江","南通","淮安","扬州")
        var locationView = LayoutInflater.from(context).inflate(R.layout.pop_location, null)

        var rvLocation = locationView.findViewById<RecyclerView>(R.id.rv_location)

        rvLocation.adapter = PopLocationAdapter(requireContext(), list)

        Log.i(TAG,"getLocationView --- >2")
        return locationView
    }


    fun getDateSelectView() : View {
        Log.i(TAG,"getDateSelectView --- >1")
        var view = LayoutInflater.from(context).inflate(R.layout.pop_date_select, null)



        return view

    }

    private val TYPE_HEADER = 0
    private val TYPE_ITEM = 1
    private var mAdapter : DrivingRecordAdapter ?= null
    private fun initAdapter() {
        for (i in 1..30) {

            if (i == 1 || i == 7 || i == 13 || i == 22) {
                var bean = RecordBean(isHeader = true, headerText = "2023年9月8日 北京")
                recordList.add(bean)
            } else {
                var bean = RecordBean(name = "00:22:20")
                recordList.add(bean)
            }
        }


        mAdapter = DrivingRecordAdapter(requireContext(), recordList)
        mBinding?.rvRecord?.adapter = mAdapter

        val spanCount = 4 // 网格列数

        // 配置跨列逻辑
        val gridLayoutManager = GridLayoutManager(requireContext(), spanCount).apply {
            // 关键配置：Header跨列，内容项正常分布
            spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    return when ( mBinding?.rvRecord?.adapter?.getItemViewType(position)) {
                        DrivingRecordAdapter.TYPE_DATE_HEADER -> spanCount
                        else -> 1
                    }
                }
            }
        }

        mBinding?.rvRecord?.layoutManager = gridLayoutManager
//        val adapter = DrivingRecordAdapter(requireContext(), recordList).apply {
//            // 添加Header
//            addHeaderView(LayoutInflater.from(requireContext())
//                .inflate(R.layout.item_layout_driving_record_header, mBinding?.rvRecord, false))
//            // 添加数据
//            items.addAll(listOf("Item 1", "Item 2", "Item 3", "Item 4","Item 5", "Item 6", "Item 7", "Item 8"))
//        }


    }


}