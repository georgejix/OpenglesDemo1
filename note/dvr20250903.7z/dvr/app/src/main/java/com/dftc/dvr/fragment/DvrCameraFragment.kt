package com.dftc.dvr.fragment

import com.dftc.dvr.DvrViewModel
import com.dftc.dvr.R
import com.dftc.dvr.databinding.FragmentDvrCameraBinding

class DvrCameraFragment : BaseFragment<FragmentDvrCameraBinding>() {
    override var TAG = javaClass.simpleName

    companion object {
        val INTENT_CAMERA_ID = "id"
    }

    override fun getLayoutId(): Int = R.layout.fragment_dvr_camera

    override fun onCreateView() {
        mBinding?.dvrVM = DvrViewModel
        addSurfaceViewListener()
    }

    override fun initView() {

    }

    override fun addListener() {

    }

    private fun getCameraId(): String? = arguments?.getString(INTENT_CAMERA_ID)

    private fun addSurfaceViewListener() {
    }
}