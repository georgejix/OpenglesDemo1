package com.dftc.dvr.bean

/**
 * @author: ZJZ
 * @date: 2025/8/28
 * @description：
 */
data class DayInfo(var year: Int, var mouth : Int, var day : Int, var selected : Boolean = false, var currentMonth : Boolean = true)
