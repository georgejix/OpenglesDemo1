package com.dftc.dvr.fragment

import android.util.Log
import android.widget.SeekBar
import androidx.viewbinding.ViewBinding
import com.dftc.dvr.bean.VideoPlayerBean

abstract class VideoPlayerFragment<T : ViewBinding> : BaseFragment<T>() {
    var mVideoPlayerBean: VideoPlayerBean? = null

    fun setVideoPlayerBean(bean: VideoPlayerBean) {
        Log.d(TAG, "setVideoPlayerBean bean=$bean")
        mVideoPlayerBean = bean
    }

    open fun play() {}

    open fun getVideoPlayerBean(): VideoPlayerBean? = mVideoPlayerBean

    open fun togglePlayPause() {}

    open fun toggleFullScreen() {}

    open fun seek(seekBar: SeekBar?) {}

    open fun setSpeed(speed: Float) {}

    open fun interceptBack(): Boolean = false
}