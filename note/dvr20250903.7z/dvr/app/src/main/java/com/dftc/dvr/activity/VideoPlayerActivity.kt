package com.dftc.dvr.activity

import android.annotation.SuppressLint
import android.media.AudioManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.SeekBar
import com.dftc.dvr.DvrViewModel
import com.dftc.dvr.R
import com.dftc.dvr.bean.PlayerStatusEnum
import com.dftc.dvr.bean.VideoPlayerBean
import com.dftc.dvr.databinding.ActivityVideoPlayerBinding
import com.dftc.dvr.databinding.LayoutPlayerSpeedBinding
import com.dftc.dvr.fragment.AvmVideoPlayerFragment
import com.dftc.dvr.fragment.DvrVideoPlayerFragment
import com.dftc.dvr.fragment.SentryVideoPlayerFragment
import com.dftc.dvr.fragment.VideoPlayerFragment
import com.dftc.dvr.view.VideoFrontView
import com.dftc.dvr.view.VideoFrontView.SeekDirection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class VideoPlayerActivity : BaseActivity<ActivityVideoPlayerBinding>() {
    override var TAG = javaClass.simpleName
    private val mAudioManager: AudioManager by lazy { getSystemService(AUDIO_SERVICE) as AudioManager }
    private val mVideoList by lazy {
        arrayListOf(
            VideoPlayerBean(
                "${getExternalFilesDir("video")}/hzw.mp4",
                "${getExternalFilesDir("video")}/hzw.mp4"
            ),
            VideoPlayerBean(
                "${getExternalFilesDir("video")}/bukegaoren.mp4",
                "${getExternalFilesDir("video")}/bukegaoren.mp4"
            )
        )
    }

    //3秒自动隐藏操作界面
    private var mHideControlJob: Job? = null

    override fun getLayoutId(): Int = R.layout.activity_video_player

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate")
        mBinding?.globalVm = DvrViewModel
        showFragment(true == mBinding?.rbMaster?.isChecked)
    }

    override fun initView() {
        super.initView()
        genHideControlJob()
    }

    override fun onPause() {
        super.onPause()
        mBinding?.layoutControl?.visibility = View.GONE
        cancelHideControlJob()
    }

    @SuppressLint("SetTextI18n")
    override fun addListener() {
        mBinding?.seekBar?.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                cancelHideControlJob()
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                genHideControlJob()
                getVideoPlayerFragment()?.seek(seekBar)
            }

        })
        mBinding?.rgAngle?.setOnCheckedChangeListener { group, checkedId ->
            genHideControlJob()
            showFragment(true == mBinding?.rbMaster?.isChecked)
        }
        mBinding?.layoutSpeed?.root?.setOnClickListener {
            mBinding?.layoutSpeed?.root?.visibility = View.GONE
            genHideControlJob()
        }
        mBinding?.layoutSpeed?.layoutSpeed?.let { layout ->
            repeat(layout.childCount) { index ->
                val tv = layout.getChildAt(index)
                val speed = (tv.tag as String).toFloat()
                tv.setOnClickListener {
                    getVideoPlayerFragment()?.setSpeed(speed)
                    mBinding?.layoutSpeed?.root?.visibility = View.GONE
                    genHideControlJob()
                }
            }
        }
    }

    fun onClick(view: View?) {
        genHideControlJob()
        view?.id?.let {
            when (it) {
                R.id.img_back -> {
                    if (true != getVideoPlayerFragment()?.interceptBack()) finish() else Unit
                }

                R.id.img_fullscreen -> {
                    getVideoPlayerFragment()?.toggleFullScreen()
                }

                R.id.img_play_pause -> {
                    getVideoPlayerFragment()?.togglePlayPause()
                }

                R.id.img_fast_backward -> playPreNext(-1)

                R.id.img_fast_forward -> playPreNext(1)

                R.id.tv_speed -> showSpeedPop()

                else -> {}
            }
        }
    }

    private fun cancelHideControlJob() {
        mHideControlJob?.cancel()
        mHideControlJob = null
    }

    private fun genHideControlJob() {
        cancelHideControlJob()
        mHideControlJob = CoroutineScope(Dispatchers.Main).launch {
            delay(3500)
            mBinding?.layoutControl?.visibility = View.GONE
        }
    }

    private fun playPreNext(add: Int) {
        getVideoPlayerFragment()?.let {
            it.setVideoPlayerBean(getNextPath(add))
            it.play()
            val index = mVideoList.indexOf(it.getVideoPlayerBean())
            mBinding?.imgFastBackward?.isEnabled = 0 < index
            mBinding?.imgFastForward?.isEnabled = mVideoList.size - 1 > index
        }
    }

    private fun showFragment(isDvr: Boolean) {
        supportFragmentManager.beginTransaction()
            .replace(
                R.id.layout_fragment,
                /*(if (isDvr) DvrVideoPlayerFragment() else AvmVideoPlayerFragment())*/
                SentryVideoPlayerFragment().also {
                    it.setVideoPlayerBean(mVideoList[0])
                }).commit()
    }

    private fun getVideoPlayerFragment(): VideoPlayerFragment<*>? =
        supportFragmentManager.fragments.find {
            (it is VideoPlayerFragment<*>) && it.isResumed
        } as VideoPlayerFragment<*>?

    private fun setBrightness(percent: Float) {
        val lp = window.attributes
        var value = lp.screenBrightness + percent
        value = Math.min(value, 1f)
        value = Math.max(value, 0.1f)
        lp.screenBrightness = value
        window.attributes = lp
        Log.d(TAG, "setBrightness $value")
    }

    private fun setVolume(percent: Float) {
        val currentV = mAudioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val maxVolume = mAudioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val value = currentV + (percent * maxVolume).toInt()
        Log.d(TAG, "setVolume percent=$percent $currentV to $value maxVolume=$maxVolume")
        mAudioManager.setStreamVolume(AudioManager.STREAM_MUSIC, value, AudioManager.FLAG_SHOW_UI)
    }

    private fun getNextPath(next: Int): VideoPlayerBean {
        val currentData = getVideoPlayerFragment()?.getVideoPlayerBean()
        val index = mVideoList.indexOf(currentData)
        return mVideoList[(index + next) % mVideoList.size].also {
            Log.d(TAG, "getNextPath bean=$it")
        }
    }

    private fun showSpeedPop() {
        val marginStart = 384
        val marginBottom = 128
        val lp = mBinding?.layoutSpeed?.layoutSpeed?.layoutParams as FrameLayout.LayoutParams?
        lp?.marginStart = marginStart
        lp?.bottomMargin = marginBottom
        mBinding?.layoutSpeed?.layoutSpeed?.layoutParams = lp
        mBinding?.layoutSpeed?.root?.visibility = View.VISIBLE
        cancelHideControlJob()
    }

    fun updatePlayPause(isPlaying: Boolean) {
        mBinding?.imgPlayPause?.setImageResource(
            if (isPlaying) R.drawable.selector_pause else R.drawable.selector_play
        )
    }

    fun updateTitle(title: String) {
        mBinding?.tvTitle?.text = title
    }

    fun updateSpeed(speed: Float) {
        mBinding?.tvSpeed?.text = "${speed}X"
    }

    fun updateCurrentTime(progress: Int, timeStr: String) {
        mBinding?.tvTime?.text = timeStr
        mBinding?.seekBar?.progress = progress
    }

    fun updateDuration(timeStr: String) {
        mBinding?.tvDuration?.text = timeStr
    }

    fun onFrontViewClick(doubleClick: Boolean) {
        mBinding?.layoutControl?.let { controlView ->
            if (doubleClick) {
                getVideoPlayerFragment()?.togglePlayPause()
            } else {
                if (View.VISIBLE == controlView.visibility) {
                    controlView.visibility = View.GONE
                    cancelHideControlJob()
                } else {
                    controlView.visibility = View.VISIBLE
                    genHideControlJob()
                }
            }
        }
    }

    fun onFrontViewSeek(dir: SeekDirection?, change: Float) {
        if (SeekDirection.LEFT == dir) {
            setBrightness(change)
        } else if (SeekDirection.RIGHT == dir) {
            setVolume(change)
        }
    }

    fun onCodecCb(status: PlayerStatusEnum, what: Int?, extra: Int?) {
        when (status) {
            PlayerStatusEnum.COMPLETION -> {
                if (false == mBinding?.seekBar?.isPressed) {
                    playPreNext(1)
                } else {
                    Log.d(TAG, "seekbar pressed")
                }
            }

            PlayerStatusEnum.ERROR -> playPreNext(1)

            else -> {}
        }
    }
}