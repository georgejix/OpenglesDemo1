package com.dftc.dvr.bean

import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraDevice
import android.view.Surface

data class CameraBean(
    var mCameraId: String? = null,
    var mSurface: Surface,
    var mCameraDevice: CameraDevice? = null,
    var mCameraCaptureSession: CameraCaptureSession? = null,
)