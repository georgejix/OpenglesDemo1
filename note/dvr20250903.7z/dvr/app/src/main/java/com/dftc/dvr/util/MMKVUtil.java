package com.dftc.dvr.util;

import android.content.Context;
import android.util.Log;

import com.tencent.mmkv.MMKV;

/**
 * Description:
 * Author: zjz
 * Date:2023/10/12 10:58
 */
public class MMKVUtil {
    private final String TAG = MMKVUtil.class.getSimpleName();
    private MMKV mmkv;
    private static class Holder {
        private static final MMKVUtil INSTANCE = new MMKVUtil();
    }

    public static MMKVUtil getInstance() {
        return Holder.INSTANCE;
    }

    public void initMMKV(Context context) {
        String rootDir = MMKV.initialize(context);
        Log.i(TAG,"initMMKV --- > mmkv root: " + rootDir);
        mmkv = MMKV.defaultMMKV();
    }


    public void encode(String key, Object value) {
        if (value instanceof String) {
            mmkv.encode(key, (String) value);
        } else if (value instanceof Integer) {
            mmkv.encode(key, (Integer) value);
        } else if (value instanceof Boolean) {
            mmkv.encode(key, (Boolean) value);
        } else if (value instanceof Long) {
            mmkv.encode(key, (Long) value);
        } else if (value instanceof Float) {
            mmkv.encode(key, (Float) value);
        } else if (value instanceof Double) {
            mmkv.encode(key, (Double) value);
        }
    }


    public Integer decodeInt(String key) {
        return mmkv.decodeInt(key);
    }

    public String decodeString(String key) {
        return mmkv.decodeString(key, "");
    }

    public Boolean decodeBoolean(String key) {
        return mmkv.decodeBool(key);
    }

    public Long decodeLong(String key) {
        return mmkv.decodeLong(key);
    }

    public Float decodeFloat(String key) {
        return mmkv.decodeFloat(key);
    }

    public Double decodeDouble(String key) {
        return mmkv.decodeDouble(key);
    }

    public void clearAllData(){
        mmkv.clearAll();
    }


}
