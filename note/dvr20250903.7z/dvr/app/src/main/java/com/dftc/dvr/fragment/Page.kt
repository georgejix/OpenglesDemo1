package com.dftc.dvr.fragment

/**
 * @author: ZJZ
 * @date: 2025/8/18
 * @description：
 */
sealed class Page(val title: String) {
    object RealTimeDisplay : Page("实时显示")
    object DrivingRecord : Page("行车记录")
    object SentryMode : Page("哨兵模式")
    object Setting : Page("设置")

    companion object {
        val pages = listOf(RealTimeDisplay, DrivingRecord, SentryMode, Setting)
    }
}
