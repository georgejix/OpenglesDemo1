package com.dftc.dvr.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.dftc.dvr.db.bean.RecordInfo
import com.dftc.dvr.db.dao.RecordInfoDao

/**
 * @author: ZJZ
 * @date: 2025/8/26
 * @description：
 */
@Database(entities = [RecordInfo::class], version = 1, exportSchema = false)
abstract class RecordInfoDB  : RoomDatabase() {
    abstract fun recordInfoDao(): RecordInfoDao

    companion object {
        private var droneInfoDB: RecordInfoDB? = null
        fun getInstance(context: Context): RecordInfoDB? {
            if (droneInfoDB == null) {
                droneInfoDB = Room.databaseBuilder<RecordInfoDB>(
                    context.applicationContext,
                    RecordInfoDB::class.java,
                    "record_info.db"
                ).build()
            }
            return droneInfoDB
        }


    }
}