package com.dftc.dvr.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.dftc.dvr.R
import com.dftc.dvr.constants.MMKVKeyConstant
import com.dftc.dvr.databinding.FragmentSettingBinding
import com.dftc.dvr.util.MMKVUtil
import com.dftc.dvr.widget.CustomCheckBoxLayout
import com.nesinext.service.extbroker.ExtBrokerManager
import com.nesinext.service.extbroker.VehiclePropertyIds

/**
 * @author: ZJZ
 * @date: 2025/8/13
 * @description：
 */
class SettingFragment : BaseFragment<FragmentSettingBinding>() {
    override fun getLayoutId(): Int = R.layout.fragment_setting

    override fun onCreateView() {
        initStorageInfo()
    }


    override fun addListener() {
        super.addListener()

        mBinding?.cbLoopRecord?.setOnCheckedChangeListener { _, isChecked ->
            MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_LOOP_RECORD, isChecked)
        }

        mBinding?.rgLoopTime?.setOnCheckedChangeListener { _, checkedId ->
            when(checkedId) {
                R.id.rb_1_minute -> MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_LOOP_RECORD_TIME, 1)
                R.id.rb_2_minute -> MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_LOOP_RECORD_TIME, 2)
                R.id.rb_5_minute -> MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_LOOP_RECORD_TIME, 5)
            }
        }

        mBinding?.cbDriveInfo?.setOnCheckedChangeListener { _, isChecked ->
            MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_DRIVE_INFO, isChecked)
        }

        mBinding?.cbVoiceRecord?.setOnCheckedChangeListener { _, isChecked ->
            MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_RECORD_VOICE, isChecked)
        }

        mBinding?.rgRecordPerspective?.setOnCheckedChangeListener { _, checkedId ->
            when(checkedId) {
                R.id.rb_main_perspective -> MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_RECORD_PERSPECTIVE, 1)
                R.id.rb_full_perspective -> MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_RECORD_PERSPECTIVE, 2)
            }
        }

        mBinding?.cbSentryMode?.setOnCheckedChangeListener { _, isChecked ->
            MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_SENTRY_MODE, isChecked)
            mBinding?.cbHome?.setEnable(isChecked)
            mBinding?.cbCompany?.setEnable(isChecked)
            mBinding?.cbCollect?.setEnable(isChecked)
        }

        mBinding?.cbHome?.setCheckedCallback(object : CustomCheckBoxLayout.CheckedCallback {
            override fun checked(isChecked: Boolean) {
                MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_SENTRY_MODE_HOME, isChecked)
            }
        })

        mBinding?.cbCompany?.setCheckedCallback(object : CustomCheckBoxLayout.CheckedCallback {
            override fun checked(isChecked: Boolean) {
                MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_SENTRY_MODE_COMPANY, isChecked)
            }
        })

        mBinding?.cbCollect?.setCheckedCallback(object : CustomCheckBoxLayout.CheckedCallback {
            override fun checked(isChecked: Boolean) {
                MMKVUtil.getInstance().encode(MMKVKeyConstant.KEY_SENTRY_MODE_COLLECT, isChecked)
            }
        })

        mBinding?.btnClearData?.setOnClickListener {
            // TODO: 删除指定数据
        }
    }

    private fun initStorageInfo() {
        mBinding?.pvStorage?.setProgress(100f, 10f, 20f, 30f)
        mBinding?.tvStorage?.text = "12.22GB/14.66GB"
        mBinding?.tvLoopStorage?.text = "12GB"
        mBinding?.tvUrgentStorage?.text = "12GB"
        mBinding?.tvSentryStorage?.text = "12GB"
    }
}