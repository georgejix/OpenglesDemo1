package com.dftc.dvr.fragment


import android.view.SurfaceHolder
import android.view.View
import com.dftc.dvr.R
import com.dftc.dvr.databinding.FragmentRealTimeDisplayBinding
import com.dftc.dvr.util.LogPrint
import com.dftc.dvr.util.DvrServiceUtil
import com.dftc.dvr.viewmodel.RealTimeDisplayViewModel
import com.dftc.dvraidl.DvrAidlConstant

/**
 * @author: ZJZ
 * @date: 2025/8/13
 * @description：
 */
class RealTimeDisplayFragment : BaseFragment<FragmentRealTimeDisplayBinding>() {

    override fun getLayoutId(): Int = R.layout.fragment_real_time_display

    override fun onCreateView() {
        mBinding?.dvrVM = RealTimeDisplayViewModel
        addSurfaceViewListener()
    }


    override fun addListener() {
        super.addListener()

        mBinding?.rgPerspective?.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.rb_main_perspective -> showMainPre()
                R.id.rb_full_perspective -> showFullPre()
            }
        }
    }

    private fun showMainPre() {
        mBinding?.rlMain?.visibility = View.VISIBLE
        mBinding?.clFull?.visibility = View.GONE
    }

    private fun showFullPre() {
        mBinding?.rlMain?.visibility = View.GONE
        mBinding?.clFull?.visibility = View.VISIBLE
    }

    private fun addSurfaceViewListener() {
        listOfNotNull(mBinding?.sv, mBinding?.sv1, mBinding?.sv2, mBinding?.sv3, mBinding?.sv4)
            .forEach { view ->
                view.holder?.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(holder: SurfaceHolder) {
                        LogPrint.Debug(TAG, "surfaceCreated")
                        view.tag.toString().takeIf { it.isNotEmpty() }?.let { id ->
                            LogPrint.Debug(TAG, "open camera $id")
                            DvrServiceUtil.setPreview(DvrAidlConstant.PREVIEW_TYPE_DVR, holder.surface)
                        }
                    }

                    override fun surfaceChanged(
                        holder: SurfaceHolder, format: Int, width: Int, height: Int
                    ) {
                        LogPrint.Debug(TAG, "surfaceChanged width=$width height=$height")
                        DvrServiceUtil.setPreviewSize(DvrAidlConstant.PREVIEW_TYPE_DVR, width, height)
                    }

                    override fun surfaceDestroyed(holder: SurfaceHolder) {
                        LogPrint.Debug(TAG, "surfaceDestroyed")
                        DvrServiceUtil.removePreview(DvrAidlConstant.PREVIEW_TYPE_DVR)
                    }
                })
            }
    }
}