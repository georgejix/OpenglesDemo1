package com.dftc.dvr.bean

/**
 * @author: ZJZ
 * @date: 2025/8/28
 * @description：
 */
data class MonthInfo(var month : Int, var selected : Boolean = false)
