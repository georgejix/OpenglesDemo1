package com.dftc.dvr.widget

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import com.dftc.dvr.R

/**
 * @author: ZJZ
 * @date: 2023/11/3
 * @description：
 */
class DrivingInfoLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {
    private val TAG = "DrivingInfoLayout"
    private lateinit var mTvSpeed : TextView
    private lateinit var mTcTime: TextClock

    private var isMainPre: Boolean = true

    private var ivAEBLight : ImageView ?= null
    private var ivAcc : ImageView ?= null

    private var ivP2p : ImageView ?= null
    private var ivLDW : ImageView ?= null
    private var ivMultilane : ImageView ?= null //多车道
    private var ivEsaLight : ImageView ?= null
    private var ivBrakeMalfunctionLight : ImageView ?= null //制动系统故障灯
    private var ivBrakeDegree : ImageView ?= null //制动开合度
    private var ivBrake : ImageView ?= null
    private var ivSeatBelt : ImageView ?= null
    private var ivHighBeam : ImageView ?= null

    private var ivLowBeam : ImageView ?= null
    private var ivLeftTurn : ImageView ?= null
    private var ivGear : ImageView ?= null
    private var ivRightTurn : ImageView ?= null


    init {
        val array = context.obtainStyledAttributes(attrs, R.styleable.driving_info_style)
        isMainPre = array.getBoolean(R.styleable.driving_info_style_isMianPre, true)
        init(context)
    }

    private fun init(context: Context?) {
        Log.i(TAG,"init -------------------- > isMainPre : $isMainPre")
        val view = LayoutInflater.from(context).inflate(if (isMainPre)R.layout.layout_driving_info_main_pre else R.layout.layout_driving_info_full_pre, this)
        mTvSpeed = view.findViewById(R.id.tv_speed)
        mTcTime = view.findViewById(R.id.textClock)


//        if (isMainPre) {
//            mTvSpeed.setTextSize(TypedValue.COMPLEX_UNIT_PX, 28f)
//            mTcTime.setTextSize(TypedValue.COMPLEX_UNIT_PX, 28f)
//        } else {
//            mTvSpeed.setTextSize(TypedValue.COMPLEX_UNIT_PX, 20f)
//            mTcTime.setTextSize(TypedValue.COMPLEX_UNIT_PX, 20f)
//        }
//
//
//        var params = if (isMainPre) ViewGroup.MarginLayoutParams(56, 56) else ViewGroup.MarginLayoutParams(36, 36)
//        params.setMargins(16, 0, 0, 0)
//
//        ivAEBLight = ImageView(context).apply {
//            layoutParams = params
//            setBackgroundResource(R.mipmap.icon_aeb_off)
//        }
//        mLyImg.addView(ivAEBLight)
//
//        ivAcc = ImageView(context).apply {
//            layoutParams = params
//            setBackgroundResource(R.mipmap.icon_aeb_off)
//        }
//        mLyImg.addView(ivAcc)
//
//        ivP2p = ImageView(context).apply {
//            layoutParams = params
//            setBackgroundResource(R.mipmap.icon_aeb_off)
//        }
//        mLyImg.addView(ivP2p)
    }



    private fun getP() {
        var img = ImageView(context)

    }
}