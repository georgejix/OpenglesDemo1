package com.dftc.dvr.bean

enum class SentryAngleEnum {
    FRONT,
    BACK,
    LEFT,
    RIGHT,
    ;
}