package com.dftc.dvr.util

import java.io.File
import java.io.IOException

/**
 * @author: ZJZ
 * @date: 2025/8/25
 * @description：
 */
object Export2UsbUtil {
    fun exportToUsb(sourceFile: File, usbPath: String) {
        val targetFile = File(usbPath, sourceFile.name)
        try {
            sourceFile.copyTo(targetFile, overwrite = true)
        } catch (e: IOException) {
            e.printStackTrace()

        }
    }
}