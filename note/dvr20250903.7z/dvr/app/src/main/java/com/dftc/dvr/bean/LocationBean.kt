package com.dftc.dvr.bean

/**
 * @author: ZJZ
 * @date: 2025/8/18
 * @description：
 */
data class LocationBean(var location : String = "", var checked : Boolean = false)
