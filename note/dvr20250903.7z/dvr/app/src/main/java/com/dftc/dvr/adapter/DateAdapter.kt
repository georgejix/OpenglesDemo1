package com.dftc.dvr.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.dftc.dvr.R
import com.dftc.dvr.bean.DayInfo
import com.dftc.dvr.databinding.ItemLayoutDatePickerBinding


/**
 * @author: ZJZ
 * @date: 2025/8/18
 * @description：
 */
class DateAdapter(private val context: Context, private var groupedData: List<DayInfo>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    companion object {
        private const val TAG = "DateAdapter"
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemLayoutDatePickerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return DateItemHolder(binding)
    }

    override fun getItemCount(): Int = groupedData.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is DateItemHolder) {
            var day = groupedData[position]
            holder.bind(day)

            holder.itemView.setOnClickListener {
                day.selected = !day.selected
                notifyDataSetChanged()
            }
        }
    }


    class DateItemHolder(private val binding: ItemLayoutDatePickerBinding) : RecyclerView.ViewHolder(binding.root) {

        private val colorState1 = ContextCompat.getColorStateList(binding.tvTime.context, R.color.selector_month_other_tv_color)
        private val colorState2 = ContextCompat.getColorStateList(binding.tvTime.context, R.color.selector_location_tv_color)
        fun bind(item: DayInfo) {
            Log.i(TAG,"bind -------------")
            binding.tvTime.text = item.day.toString()

            if (item.currentMonth) {
                binding.tvTime.setTextColor(colorState2)
            } else {
                binding.tvTime.setTextColor(colorState1)
            }
            binding.tvTime.isSelected = item.selected

        }
    }

}