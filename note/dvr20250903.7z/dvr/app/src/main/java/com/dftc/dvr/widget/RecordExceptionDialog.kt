package com.dftc.dvr.widget

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import androidx.databinding.DataBindingUtil
import com.dftc.dvr.R
import com.dftc.dvr.databinding.DialogRecordExceptionBinding
import com.dftc.dvr.databinding.DialogRecordOperationBinding

/**
 * @author: ZJZ
 * @date: 2025/8/20
 * @description：
 */
class RecordExceptionDialog(context: Context) : Dialog(context,R.style.TransparentDialog) {
    private lateinit var binding: DialogRecordExceptionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.dialog_record_exception, null, false)
        setContentView(binding.root)
    }



    class Builder(private val context: Context) {
        private var tip: String = ""
        private var message: String = ""
        private var positiveText: String = "确定"
        private var positiveAction: (() -> Unit)? = null

        fun setTip(tip: String): Builder {
            this.tip = tip
            return this
        }

        fun setPositiveButton(action: () -> Unit): Builder {
            this.positiveAction = action
            return this
        }

        fun build(): RecordExceptionDialog {
            val dialog = RecordExceptionDialog(context)

            dialog.setCancelable(false)
            dialog.setOnShowListener {
                dialog.binding.tvTip.text = tip

                dialog.binding.btnConfirm.setOnClickListener {
                    positiveAction?.invoke()
                    dialog.dismiss()
                }
            }
            return dialog
        }
    }
}