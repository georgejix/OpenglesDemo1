package com.dftc.dvr.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.dftc.dvr.db.bean.RecordInfo

/**
 * @author: ZJZ
 * @date: 2025/8/26
 * @description：
 */
@Dao
interface RecordInfoDao {
    @Insert
    fun insert(vararg info: RecordInfo)

    @Query("SELECT * FROM RecordInfo")
    fun queryAll(): List<RecordInfo?>?
}