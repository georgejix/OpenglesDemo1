package com.dftc.dvr.fragment

import android.util.Log
import android.view.SurfaceHolder
import android.view.View
import android.widget.FrameLayout
import android.widget.SeekBar
import androidx.constraintlayout.widget.ConstraintLayout
import com.dftc.dvr.DvrViewModel
import com.dftc.dvr.R
import com.dftc.dvr.activity.VideoPlayerActivity
import com.dftc.dvr.adapter.SentryAngleAdapter
import com.dftc.dvr.bean.PlayerStatusEnum
import com.dftc.dvr.bean.SentryAngleBean
import com.dftc.dvr.bean.SentryAngleEnum
import com.dftc.dvr.databinding.FragmentSentryVideoPlayerBinding
import com.dftc.dvr.util.LocalMediaPlayer

class SentryVideoPlayerFragment : VideoPlayerFragment<FragmentSentryVideoPlayerBinding>() {
    override var TAG = javaClass.simpleName
    private val mLocalMediaPlayer by lazy { LocalMediaPlayer() }
    private var mSentryAngleAdapter: SentryAngleAdapter? = null
    private val mDefaultWidth = 1888
    private val mDefaultHeight = 990

    override fun getLayoutId(): Int = R.layout.fragment_sentry_video_player

    override fun onCreateView() {
        mBinding?.globalVm = DvrViewModel
        addSurfaceViewListener()
    }

    override fun onResume() {
        super.onResume()
        mLocalMediaPlayer.startListen()
    }

    override fun onPause() {
        super.onPause()
        mLocalMediaPlayer.pause()
        mLocalMediaPlayer.stopListen()
    }

    override fun onDestroy() {
        super.onDestroy()
        mLocalMediaPlayer.release()
    }

    override fun initView() {
        context?.let { c ->
            mSentryAngleAdapter = SentryAngleAdapter(
                c, listOf(
                    SentryAngleBean(SentryAngleEnum.FRONT, "", ""),
                    SentryAngleBean(SentryAngleEnum.BACK, "", ""),
                    SentryAngleBean(SentryAngleEnum.LEFT, "", ""),
                    SentryAngleBean(SentryAngleEnum.RIGHT, "", "")
                )
            ) { item ->
                refreshAngle()
            }
            mBinding?.rvAngle?.adapter = mSentryAngleAdapter
        }
    }

    override fun addListener() {
        mLocalMediaPlayer.setCb() { status, what, extra ->
            when (status) {
                PlayerStatusEnum.VIDEO_SIZE -> {
                    changeSurfaceViewSize(false)
                }

                else -> getVideoPlayerActivity()?.onCodecCb(status, what, extra)
            }
        }
        mLocalMediaPlayer.mPlayingLD.observe(this) { isPlaying ->
            getVideoPlayerActivity()?.updatePlayPause(isPlaying)
        }
        mLocalMediaPlayer.mTitleLD.observe(this) { title ->
            getVideoPlayerActivity()?.updateTitle(title)
        }
        mLocalMediaPlayer.mSpeedLD.observe(this) { speed ->
            getVideoPlayerActivity()?.updateSpeed(speed)
        }
        mLocalMediaPlayer.mCurrentTimeLD.observe(this) { time ->
            mLocalMediaPlayer.getDuration().takeIf { it > 0 }?.let {
                getVideoPlayerActivity()?.updateCurrentTime(
                    (time * 1000 / it).toInt(),
                    mLocalMediaPlayer.formatTime(time / 1000)
                )
            }
        }
        mLocalMediaPlayer.mDurationLD.observe(this) { time ->
            getVideoPlayerActivity()?.updateDuration(mLocalMediaPlayer.formatTime(time / 1000))
        }
        mBinding?.viewFront?.setClickListener { doubleClick ->
            getVideoPlayerActivity()?.onFrontViewClick(doubleClick)
        }
        mBinding?.viewFront?.setSeekListener { dir, change ->
            getVideoPlayerActivity()?.onFrontViewSeek(dir, change)
        }
    }

    private fun addSurfaceViewListener() {
        mBinding?.sv?.holder?.addCallback(
            object : SurfaceHolder.Callback {
                override fun surfaceCreated(holder: SurfaceHolder) {
                    Log.d(TAG, "surfaceCreated")
                    if (mLocalMediaPlayer.getDataSource().isEmpty()) {
                        play()
                    } else {
                        mLocalMediaPlayer.setSurface(holder.surface)
                    }
                }

                override fun surfaceChanged(
                    holder: SurfaceHolder, format: Int, width: Int, height: Int
                ) {
                    Log.d(TAG, "surfaceChanged width=$width height=$height")
                    //surface创建后，需要调整一次角度
                    if (mBinding?.sv?.width == mBinding?.cardSv?.width) {
                        refreshAngle()
                    }
                    if (mLocalMediaPlayer.getDataSource().isNotEmpty()) {
                        mLocalMediaPlayer.setSurface(holder.surface)
                    }
                }

                override fun surfaceDestroyed(holder: SurfaceHolder) {
                    Log.d(TAG, "surfaceDestroyed")
                    mLocalMediaPlayer.setSurface(null)
                }

            })
    }

    private fun refreshAngle() {
        Log.d(TAG, "refreshAngle")
        mSentryAngleAdapter?.getSelectedType()?.let { type ->
            val width = (mBinding?.layoutFragmentBg?.width ?: mDefaultWidth) * 2
            val height = (mBinding?.layoutFragmentBg?.height ?: mDefaultHeight) * 2
            val lp = mBinding?.sv?.layoutParams as FrameLayout.LayoutParams
            lp.width = width
            lp.height = height
            lp.marginStart = when (type) {
                SentryAngleEnum.FRONT -> 0
                SentryAngleEnum.BACK -> -width / 2
                SentryAngleEnum.LEFT -> 0
                SentryAngleEnum.RIGHT -> -width / 2
            }
            lp.topMargin = when (type) {
                SentryAngleEnum.FRONT -> 0
                SentryAngleEnum.BACK -> 0
                SentryAngleEnum.LEFT -> -height / 2
                SentryAngleEnum.RIGHT -> -height / 2
            }
            mBinding?.sv?.layoutParams = lp
        }
    }

    private fun changeSurfaceViewSize(toggle: Boolean) {
        Log.d(TAG, "changeSurfaceViewSize")
        val videoWidth = mLocalMediaPlayer.mVideoWidth
        val videoHeight = mLocalMediaPlayer.mVideoHeight
        if (videoWidth <= 0 || videoHeight <= 0 || 0 == mBinding?.cardSv?.width) return
        val isOldFullScreen = isCurrentFullScreen()
        val needFullScreen = (isOldFullScreen && !toggle) || (!isOldFullScreen && toggle)
        val pWidth = if (needFullScreen) mBinding?.layoutFragmentBg?.width
            ?: mDefaultWidth else mDefaultWidth
        val pHeight = if (needFullScreen) mBinding?.layoutFragmentBg?.height
            ?: mDefaultHeight else mDefaultHeight
        var width = 0
        var height = 0
        if (pWidth * videoHeight > pHeight * videoWidth) {
            height = pHeight
            width = height * videoWidth / videoHeight
        } else {
            width = pWidth
            height = width * videoHeight / videoWidth
        }
        val lp = mBinding?.cardSv?.layoutParams as ConstraintLayout.LayoutParams?
        lp?.width = width
        lp?.height = height
        lp?.topMargin = if (needFullScreen) 0 else 162
        lp?.leftMargin = if (needFullScreen) 0 else 551
        lp?.endToEnd = if (needFullScreen) ConstraintLayout.LayoutParams.PARENT_ID else
            ConstraintLayout.LayoutParams.UNSET
        lp?.bottomToBottom = if (needFullScreen) ConstraintLayout.LayoutParams.PARENT_ID else
            ConstraintLayout.LayoutParams.UNSET
        mBinding?.cardSv?.layoutParams = lp
        mBinding?.rvAngle?.visibility = if (needFullScreen) View.GONE else View.VISIBLE
        Log.d(TAG, "changeSurfaceViewSize set width=$width height=$height")
    }

    private fun isCurrentFullScreen(): Boolean {
        return mBinding?.cardSv?.width == mBinding?.layoutFragmentBg?.width ||
                mBinding?.cardSv?.height == mBinding?.layoutFragmentBg?.height
    }

    private fun getVideoPlayerActivity(): VideoPlayerActivity? {
        return if (activity is VideoPlayerActivity) activity as VideoPlayerActivity else null
    }

    override fun play() {
        Log.d(TAG, "play path=${mVideoPlayerBean?.mDvrPath}")
        mVideoPlayerBean?.mDvrPath?.let { path ->
            mLocalMediaPlayer.initPlayer()
            mLocalMediaPlayer.setSurface(mBinding?.sv?.holder?.surface)
            mLocalMediaPlayer.setDataSource(path)
            mLocalMediaPlayer.prepareAsync()
        }
    }

    override fun togglePlayPause() {
        if (mLocalMediaPlayer.isPlaying()) {
            mLocalMediaPlayer.pause()
        } else {
            mLocalMediaPlayer.start()
        }
    }

    override fun toggleFullScreen() = changeSurfaceViewSize(true)

    override fun seek(seekBar: SeekBar?) {
        seekBar?.takeIf { mLocalMediaPlayer.getDuration() > 0 }?.let {
            val duration = it.progress * mLocalMediaPlayer.getDuration() / it.max
            mLocalMediaPlayer.seekTo(duration)
            mLocalMediaPlayer.start()
        }
    }

    override fun setSpeed(speed: Float) = mLocalMediaPlayer.setSpeed(speed)

    override fun interceptBack(): Boolean = isCurrentFullScreen().also { fullScreen ->
        if (fullScreen) toggleFullScreen()
    }
}