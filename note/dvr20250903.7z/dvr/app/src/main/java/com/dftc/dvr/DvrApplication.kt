package com.dftc.dvr

import android.app.Application
import android.content.Context
import android.content.res.Configuration
import android.util.Log
import com.dftc.dvr.util.MMKVUtil
import com.dftc.dvr.util.DvrServiceUtil

class DvrApplication : Application() {
    private val TAG = javaClass.simpleName

    companion object{
        var mApplicationContext: Context? = null
    }

    override fun onCreate() {
        super.onCreate()
        mApplicationContext = this
        DvrViewModel.setTheme(resources.configuration.uiMode)
        MMKVUtil.getInstance().initMMKV(this)
        DvrServiceUtil.init()
    }

    override fun onTerminate() {
        super.onTerminate()
        mApplicationContext = null
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.d(TAG, "onConfigurationChanged ${newConfig.uiMode}")
        DvrViewModel.setTheme(resources.configuration.uiMode)
    }
}