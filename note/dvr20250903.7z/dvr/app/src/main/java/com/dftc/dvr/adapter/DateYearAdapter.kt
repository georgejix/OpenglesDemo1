package com.dftc.dvr.adapter

import android.content.ClipData.Item
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.loader.content.Loader
import androidx.recyclerview.widget.RecyclerView
import com.dftc.dvr.R
import com.dftc.dvr.bean.DayInfo
import com.dftc.dvr.bean.MonthInfo
import com.dftc.dvr.bean.RecordBean
import com.dftc.dvr.databinding.ItemLayoutDatePickerBinding
import com.dftc.dvr.databinding.ItemLayoutDrivingRecordBinding
import com.dftc.dvr.databinding.ItemLayoutDrivingRecordHeaderBinding
import com.dftc.dvr.databinding.ItemLayoutLocationBinding
import com.dftc.dvr.databinding.ItemLayoutYearPickerBinding

/**
 * @author: ZJZ
 * @date: 2025/8/18
 * @description：
 */
class DateYearAdapter(private val context: Context, private var groupedData: List<MonthInfo>) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    companion object {
        private const val TAG = "DateYearAdapter"
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemLayoutYearPickerBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return YearItemHolder(binding)
    }

    override fun getItemCount(): Int = groupedData.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is YearItemHolder) {
            var day = groupedData[position]
            holder.bind(day)

            holder.itemView.setOnClickListener {
                mCallback?.yearMonth(position)
            }
        }
    }

    class YearItemHolder(private val binding: ItemLayoutYearPickerBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: MonthInfo) {
            Log.i(TAG,"bind -------------")
            binding.tvMonth.text = "${item.month}月"
            binding.tvMonth.isSelected = item.selected
        }
    }

    private var mCallback : YearMonthCallback ?= null
    fun setYearMonthCallback(callback : YearMonthCallback) {
        mCallback = callback
    }

    interface YearMonthCallback {
        fun yearMonth(monthPosition : Int)
    }
}