package com.dftc.dvr.widget

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import com.dftc.dvr.R
import com.dftc.dvr.adapter.DateAdapter
import com.dftc.dvr.adapter.DateYearAdapter
import com.dftc.dvr.adapter.GridSpacingDecoration
import com.dftc.dvr.bean.DayInfo
import com.dftc.dvr.bean.MonthInfo
import com.dftc.dvr.databinding.LayoutCustomDatePickerBinding
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth

/**
 * @author: ZJZ
 * @date: 2023/11/3
 * @description：
 */
class CustomDatePickerLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {
    private val TAG = "CustomDatePickerLayout"

    private var dateAdapter : DateAdapter ?=null
    private var yearAdapter : DateYearAdapter ?= null
    private var dayList : ArrayList<DayInfo> = ArrayList()
    private var monthList : ArrayList<MonthInfo> = ArrayList()
    private lateinit var binding : LayoutCustomDatePickerBinding

    private var CURRENT_YEAR = 2025
    private var CURRENT_MONTH = 1
    init {
        init()
    }


    private fun init() {
        binding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.layout_custom_date_picker, this, true)

        dateAdapter = DateAdapter(context, dayList)
        binding?.rvDate?.adapter = dateAdapter

        val dayLayoutManager = GridLayoutManager(context, 7)
        binding?.rvDate?.layoutManager = dayLayoutManager
        binding?.rvDate?.addItemDecoration(GridSpacingDecoration(7, 32, 16))


        (1..12).forEach { monthList.add(MonthInfo(it)) }
        yearAdapter = DateYearAdapter(context, monthList)
        val yearLayoutManager = GridLayoutManager(context, 4)
        binding.rvYear.layoutManager = yearLayoutManager
        binding.rvYear.adapter = yearAdapter
        binding.rvYear.addItemDecoration(GridSpacingDecoration(4, 52, 100))

        val now: LocalDateTime = LocalDateTime.now()
        CURRENT_YEAR = now.year
        CURRENT_MONTH = now.monthValue
        Log.i(TAG,"init --- > CURRENT_YEAR : $CURRENT_YEAR -- CURRENT_MONTH : $CURRENT_MONTH")
        refreshDate()



        binding.ivLeft.setOnClickListener {
            CURRENT_MONTH--
            if (CURRENT_MONTH < 1) {
                CURRENT_MONTH = 12
                CURRENT_YEAR --
            }

            refreshDate()
        }
        binding.ivRight.setOnClickListener {
            CURRENT_MONTH ++
            if (CURRENT_MONTH > 12) {
                CURRENT_MONTH = 1
                CURRENT_YEAR++
            }

            refreshDate()
        }

        binding.ivYearLeft.setOnClickListener {
            CURRENT_YEAR--
            binding.tvYearDate.text = "${CURRENT_YEAR}年"
        }

        binding.ivYearRight.setOnClickListener {
            CURRENT_YEAR++
            binding.tvYearDate.text = "${CURRENT_YEAR}年"
        }


        binding.tvDate.setOnClickListener {
            binding.lyMonth.visibility = GONE
            binding.lyYear.visibility = VISIBLE
        }

        yearAdapter?.setYearMonthCallback(object : DateYearAdapter.YearMonthCallback {
            override fun yearMonth(monthPosition: Int) {
                var showDayInfo = false
                monthList.forEachIndexed { index, monthInfo ->
                    if (index == monthPosition) {
                        monthInfo.selected = !monthInfo.selected
                        if (monthInfo.selected) {
                            showDayInfo = true
                        }
                    } else {
                        monthInfo.selected = false
                    }
                }

                yearAdapter?.notifyDataSetChanged()
                //如果有选中的，则跳转到日期也没，没有选中就停留在该页面
                if (showDayInfo) {
                    binding.lyMonth.visibility = VISIBLE
                    binding.lyYear.visibility = GONE

                    CURRENT_MONTH = monthPosition + 1
                    refreshDate()
                }
            }
        })


    }

    private fun refreshDate() {

        dayList.clear()

        val yearMonth = YearMonth.of(CURRENT_YEAR, CURRENT_MONTH) // 月份从1开始
        val days = yearMonth.lengthOfMonth()

        binding.tvDate.text = "${CURRENT_YEAR}年${CURRENT_MONTH}月"
        binding.tvYearDate.text = "${CURRENT_YEAR}年"

        val firstDayModern = LocalDate.of(CURRENT_YEAR, CURRENT_MONTH, 1).dayOfWeek
        val lastDayModern = LocalDate.of(CURRENT_YEAR, CURRENT_MONTH, 1).plusMonths(1).minusDays(1).dayOfWeek

        /**
         * 一页的总数据个数应为：上个月的剩余天数+本月天数+下个月的前面几天，上个月和下个月的天数取决于本月第一天和最后一天是周几。
         * 如果本月第一天是周日，则上个月的天数不需要，如果本月最后一天是周六，下个月的天数则不需要
         */

        var lastMouthDays = getLastMouthDays(firstDayModern)
        var nextMouthDays = getNextMouthDays(lastDayModern)

        var lastMonthAllDays = getLastMonthAllDays()
//        var nextMonthAllDays = getNextMonthAllDays()

        (1..lastMouthDays).forEach { dayList.add(DayInfo(CURRENT_YEAR, CURRENT_MONTH, lastMonthAllDays - (lastMouthDays - it), currentMonth = false)) }
        (1..days).forEach { dayList.add(DayInfo(CURRENT_YEAR, CURRENT_MONTH, it)) }
        (1..nextMouthDays).forEach { dayList.add(DayInfo(CURRENT_YEAR, CURRENT_MONTH, it, currentMonth = false)) }


        dateAdapter?.notifyDataSetChanged()

    }



    /**
     * 获取上个月的总天数
     */
    private fun getLastMonthAllDays() : Int {
        // 创建指定月份的YearMonth对象
        val specifiedMonth: YearMonth = YearMonth.of(CURRENT_YEAR, CURRENT_MONTH)
        // 获取上个月的YearMonth对象
        // 获取上个月的YearMonth对象
        val lastMonth = specifiedMonth.minusMonths(1)
        // 获取上个月的天数
        // 获取上个月的天数
        return lastMonth.lengthOfMonth()
    }

    /**
     * 使用Java 8时间API获取指定月份的下个月天数
     * @return 下个月的天数
     */
    fun getNextMonthAllDays(): Int {
        // 创建指定月份的YearMonth对象
        val specifiedMonth = YearMonth.of(CURRENT_YEAR, CURRENT_MONTH)
        // 获取下个月的YearMonth对象
        val nextMonth = specifiedMonth.plusMonths(1)
        // 获取下个月的天数
        return nextMonth.lengthOfMonth()
    }

    /**
     * 获取上个月需要显示的天数
     */
    private fun getLastMouthDays(w : DayOfWeek) : Int{
        if (w.value == 7) {
            return 0
        }

        return w.value
    }

    /**
     * 获取下个月需要显示的天数
     */
    private fun getNextMouthDays(w : DayOfWeek) : Int{
        if (w.value == 7) {
            return 6
        }

        return 6 - w.value
    }
}