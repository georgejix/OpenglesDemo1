package com.dftc.dvr.adapter

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.dftc.dvr.fragment.DrivingRecordFragment
import com.dftc.dvr.fragment.Page
import com.dftc.dvr.fragment.RealTimeDisplayFragment
import com.dftc.dvr.fragment.SentryModeFragment
import com.dftc.dvr.fragment.SettingFragment

/**
 * @author: ZJZ
 * @date: 2025/8/15
 * @description：
 */
class ViewpagerAdapter(fragmentActivity: FragmentActivity) : FragmentStateAdapter(fragmentActivity) {
    override fun getItemCount(): Int {
       return Page.pages.size
    }

    override fun createFragment(position: Int): Fragment {
        return when (Page.pages[position]) {
            is Page.RealTimeDisplay -> RealTimeDisplayFragment()
            is Page.DrivingRecord -> DrivingRecordFragment()
            is Page.SentryMode -> SentryModeFragment()
            is Page.Setting -> SettingFragment()
        }
    }
}