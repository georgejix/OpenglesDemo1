package com.dftc.dvr.bean

data class SentryAngleBean(val type: SentryAngleEnum, val angle: String, val img: String)