package com.dftc.dvr.fragment

import android.util.Log
import android.util.SparseArray
import android.view.Surface
import android.view.SurfaceHolder
import android.widget.SeekBar
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.util.forEach
import com.dftc.dvr.DvrViewModel
import com.dftc.dvr.R
import com.dftc.dvr.activity.VideoPlayerActivity
import com.dftc.dvr.bean.PlayerStatusEnum
import com.dftc.dvr.databinding.FragmentAvmVideoPlayer4Binding
import com.dftc.dvr.util.LocalMediaPlayer

class AvmVideoPlayer4Fragment : VideoPlayerFragment<FragmentAvmVideoPlayer4Binding>() {
    override var TAG = javaClass.simpleName
    private val mPlayerMap: SparseArray<LocalMediaPlayer> = SparseArray()

    override fun getLayoutId(): Int = R.layout.fragment_avm_video_player4

    override fun onCreateView() {
        mBinding?.globalVm = DvrViewModel
        addSurfaceViewListener()
    }

    override fun onResume() {
        super.onResume()
        mPlayerMap.forEach { key, value -> value.startListen() }
    }

    override fun onPause() {
        super.onPause()
        mPlayerMap.forEach { key, value ->
            value.pause()
            value.stopListen()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mPlayerMap.forEach { key, value -> value.release() }
    }

    override fun initView() {

    }

    override fun addListener() {
        getMediaPlayer()?.let { player ->
            player.setCb() { status, what, extra ->
                when (status) {
                    PlayerStatusEnum.VIDEO_SIZE -> {
                        changeSurfaceViewSize(false)
                    }

                    else -> getVideoPlayerActivity()?.onCodecCb(status, what, extra)
                }
            }
            player.mPlayingLD.observe(this) { isPlaying ->
                getVideoPlayerActivity()?.updatePlayPause(isPlaying)
            }
            player.mTitleLD.observe(this) { title ->
                getVideoPlayerActivity()?.updateTitle(title)
            }
            player.mSpeedLD.observe(this) { speed ->
                getVideoPlayerActivity()?.updateSpeed(speed)
            }
            player.mCurrentTimeLD.observe(this) { time ->
                player.getDuration().takeIf { it > 0 }?.let {
                    getVideoPlayerActivity()?.updateCurrentTime(
                        (time * 1000 / it).toInt(),
                        player.formatTime(time / 1000)
                    )
                }
            }
            player.mDurationLD.observe(this) { time ->
                getVideoPlayerActivity()?.updateDuration(player.formatTime(time / 1000))
            }
        }
    }

    private fun getMediaPlayer(): LocalMediaPlayer? = mPlayerMap.get(0)

    private fun addSurfaceViewListener() {
        arrayOf(mBinding?.sv1, mBinding?.sv2, mBinding?.sv3, mBinding?.sv4).filterNotNull()
            .forEach { sv ->
                runCatching {
                    val index = (sv.tag as String).toInt()
                    val player = LocalMediaPlayer()
                    mPlayerMap[index] = player
                    sv.holder.addCallback(
                        object : SurfaceHolder.Callback {
                            override fun surfaceCreated(holder: SurfaceHolder) {
                                Log.d(TAG, "surfaceCreated")
                                if (player.getDataSource().isEmpty()) {
                                    play(holder.surface, player)
                                } else {
                                    player.setSurface(holder.surface)
                                }
                            }

                            override fun surfaceChanged(
                                holder: SurfaceHolder, format: Int, width: Int, height: Int
                            ) {
                                Log.d(TAG, "surfaceChanged width=$width height=$height")
                                if (player.getDataSource().isEmpty()) {
                                    player.setSurface(holder.surface)
                                }
                            }

                            override fun surfaceDestroyed(holder: SurfaceHolder) {
                                Log.d(TAG, "surfaceDestroyed")
                                player.setSurface(null)
                            }
                        })
                }
            }
    }

    private fun changeSurfaceViewSize(toggle: Boolean) {
        Log.d(TAG, "changeSurfaceViewSize")
        val videoWidth = getMediaPlayer()?.mVideoWidth ?: 0
        val videoHeight = getMediaPlayer()?.mVideoHeight ?: 0
        if (videoWidth <= 0 || videoHeight <= 0) return
        val isOldFullScreen = mBinding?.cardSv?.width == mBinding?.layoutFragmentBg?.width ||
                mBinding?.cardSv?.height == mBinding?.layoutFragmentBg?.height
        val needFullScreen = (isOldFullScreen && !toggle) || (!isOldFullScreen && toggle)
        val pWidth =
            ((if (needFullScreen) mBinding?.layoutFragmentBg?.width ?: 1888 else 1888) - 16) / 2
        val pHeight =
            ((if (needFullScreen) mBinding?.layoutFragmentBg?.height ?: 990 else 990) - 16) / 2
        val marginTop = if (needFullScreen) 0 else 162
        var width = 0
        var height = 0
        if (pWidth * videoHeight > pHeight * videoWidth) {
            height = pHeight
            width = height * videoWidth / videoHeight
        } else {
            width = pWidth
            height = width * videoHeight / videoWidth
        }
        val lp = mBinding?.cardSv?.layoutParams as ConstraintLayout.LayoutParams?
        lp?.width = (width * 2) + 16
        lp?.height = (height * 2) + 16
        lp?.topMargin = marginTop
        mBinding?.cardSv?.layoutParams = lp
        Log.d(TAG, "changeSurfaceViewSize set width=${(width * 2) + 16} height=${(height * 2) + 16}")
    }

    private fun getVideoPlayerActivity(): VideoPlayerActivity? {
        return if (activity is VideoPlayerActivity) activity as VideoPlayerActivity else null
    }

    private fun play(sv: Surface?, player: LocalMediaPlayer) {
        mVideoPlayerBean?.mDvrPath?.let { path ->
            player.initPlayer()
            player.setSurface(sv)
            player.setDataSource(path)
            player.prepareAsync()
        }
    }

    override fun play() {
        Log.d(TAG, "play path=${mVideoPlayerBean?.mDvrPath}")
        val svs =
            arrayOf(mBinding?.sv1, mBinding?.sv2, mBinding?.sv3, mBinding?.sv4).filterNotNull()
        mPlayerMap.forEach { tag, player ->
            play(svs.find { it.tag == "$tag" }?.holder?.surface, player)
        }
    }

    override fun togglePlayPause() {
        mPlayerMap.forEach { tag, player ->
            if (player.isPlaying()) {
                player.pause()
            } else {
                player.start()
            }
        }
    }

    override fun toggleFullScreen() = changeSurfaceViewSize(true)

    override fun seek(seekBar: SeekBar?) {
        getMediaPlayer()?.let { player ->
            seekBar?.takeIf { player.getDuration() > 0 }?.let {
                val duration = it.progress * player.getDuration() / it.max
                player.seekTo(duration)
                player.start()
            }
        }
    }
}