package com.dftc.dvr.widget

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.animation.LinearInterpolator
import androidx.databinding.DataBindingUtil
import com.dftc.dvr.R
import com.dftc.dvr.databinding.DialogRecordLoadingBinding
import com.dftc.dvr.databinding.DialogRecordOperationBinding

/**
 * @author: ZJZ
 * @date: 2025/8/20
 * @description：
 */
class RecordLoadingDialog(context: Context) : Dialog(context,R.style.TransparentDialog) {
    private lateinit var binding: DialogRecordLoadingBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.inflate(LayoutInflater.from(context), R.layout.dialog_record_loading, null, false)
        setContentView(binding.root)
    }



    class Builder(private val context: Context) {
        private var tip: String = ""
        private var message: String = ""
        private var positiveText: String = "确定"
        private var positiveAction: (() -> Unit)? = null

        fun setTip(tip: String): Builder {
            this.tip = tip
            return this
        }

        fun setPositiveButton(action: () -> Unit): Builder {
            this.positiveAction = action
            return this
        }

        fun build(): RecordLoadingDialog {
            val dialog = RecordLoadingDialog(context)

            dialog.setCancelable(true)
            dialog.setOnShowListener {
                ObjectAnimator.ofFloat(dialog.binding.ivLoading, "rotation", 0f, 360f).apply {
                    duration = 2000       // 旋转周期2秒
                    repeatCount = ValueAnimator.INFINITE  // 无限循环
                    interpolator = LinearInterpolator()   // 匀速旋转
                    start()
                }

            }
            return dialog
        }
    }
}