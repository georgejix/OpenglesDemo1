package com.dftc.dvr.bean

data class VideoPlayerBean(var mDvrPath: String, var mAvmPath: String)