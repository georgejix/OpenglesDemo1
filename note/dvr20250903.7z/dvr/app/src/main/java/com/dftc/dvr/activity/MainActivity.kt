package com.dftc.dvr.activity

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.util.Log
import com.dftc.dvr.DvrViewModel
import com.dftc.dvr.R
import com.dftc.dvr.adapter.ViewpagerAdapter
import com.dftc.dvr.databinding.ActivityMainBinding

//手动更换主题颜色
class MainActivity : BaseActivity<ActivityMainBinding>() {
    override var TAG = javaClass.simpleName
    override fun getLayoutId() = R.layout.activity_main

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "onCreate")
        super.onCreate(savedInstanceState)
        mBinding?.dvrVM = DvrViewModel
//        ActivityCompat.requestPermissions(this, needPermissions(), 1)
//        startActivity(Intent(this,VideoPlayerActivity::class.java))
    }

    override fun addListener() {
        mBinding?.rgTab?.setOnCheckedChangeListener { _, checkedId ->

            mBinding?.vpFragment?.currentItem = when(checkedId) {
                R.id.rb_realtime -> 0
                R.id.rb_record -> 1
                R.id.rb_sentry_mode -> 2
                R.id.rb_setting -> 3
                else -> 0
            }
        }
    }

    override fun initView() {
        // 设置 ViewPager2 适配器
        mBinding?.vpFragment?.adapter = ViewpagerAdapter(this)
        mBinding?.vpFragment?.setPageTransformer { page, _ -> page.translationX = 0f }
        mBinding?.vpFragment?.isUserInputEnabled = false
        // 将 TabLayout 与 ViewPager2 联动
//        TabLayoutMediator(mBinding?.tlTitle!!, mBinding?.vpFragment!!) { tab, position ->
//            tab.text = Page.pages[position].title
//        }.attach()
//
//        mBinding?.tlTitle.setupWithViewPager()
    }

    private fun updateFragment() {

    }



    override fun needPermissions(): Array<String> =
        arrayOf(Manifest.permission.CAMERA /*Manifest.permission.WRITE_EXTERNAL_STORAGE*/)

    override fun onPermissionCb(get: Boolean) {
        super.onPermissionCb(get)
        if (get) {
//            CameraUtil.mCameraManager = getSystemService(CameraManager::class.java)
//            CameraUtil.mCameraManager?.cameraIdList?.last()?.let { id ->
//                supportFragmentManager.beginTransaction()
//                    .replace(R.id.layout_frame, AvmCameraFragment().also {
//                        val bundle = Bundle()
//                        bundle.putString(AvmCameraFragment.INTENT_CAMERA_ID, id)
//                        it.arguments = bundle
//                    }).commit()
//            }
        }
    }
}
