package com.dftc.dvr.viewmodel

import android.content.res.Configuration
import android.util.Log
import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel

object RealTimeDisplayViewModel : ViewModel() {
    private val TAG = javaClass.simpleName
    val mThemeDay = "day"
    val mThemeNight = "night"
    var mTheme = ObservableField<String>("")

    fun setTheme(uiMode: Int) {
        if (uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES) {
            // 处于深色模式
            Log.d(TAG, "setTheme dark mode")
            mTheme.set(mThemeNight)
        } else {
            // 处于浅色模式
            Log.d(TAG, "setTheme light mode")
            mTheme.set(mThemeDay)
        }
    }
}