package com.dftc.dvr.widget

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.dftc.dvr.R

/**
 * @author: ZJZ
 * @date: 2023/11/3
 * @description：
 */
class CustomCheckBoxLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {
    lateinit var mIvChecked: ImageView
    lateinit var mCbText: CheckBox
    val text: String?
    init {
        val array = context.obtainStyledAttributes(attrs, R.styleable.check_style)
        text = array.getString(R.styleable.check_style_text)
        init(context)
    }

    private fun init(context: Context?) {
        val view = LayoutInflater.from(context).inflate(R.layout.layout_custom_checkbox, this)
        mIvChecked = view.findViewById(R.id.iv_checked)
        mCbText = view.findViewById(R.id.cb_text)

        text?.let {
            mCbText.text = it
        }


        mCbText.setOnCheckedChangeListener { _, isChecked ->
            mIvChecked.visibility = if (isChecked) VISIBLE else GONE
            mCallback?.checked(isChecked)
        }
    }

    fun setText(text : String) {
        mCbText.text = text
    }

    fun setChecked(isChecked: Boolean) {
        mCbText.isChecked = isChecked
    }


    private var mEnable : Boolean = true
    fun setEnable(enable : Boolean) {
        mEnable = enable
        alpha = if (enable) 1f else 0.3f

    }


    override fun onInterceptTouchEvent(ev: MotionEvent?): Boolean {
        if (!mEnable) {
            return true
        }
        return super.onInterceptTouchEvent(ev)
    }


    private var mCallback : CheckedCallback ?= null
    fun setCheckedCallback(callback: CheckedCallback) {
        mCallback = callback
    }

    interface CheckedCallback {
        fun checked(isChecked : Boolean)
    }
}