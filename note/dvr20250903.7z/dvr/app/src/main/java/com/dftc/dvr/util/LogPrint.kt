package com.dftc.dvr.util

import android.util.Log

object LogPrint {
    fun Info(tag: String, msg: String) = Log.i(tag, msg)
    fun Debug(tag: String, msg: String) = Log.d(tag, msg)
    fun Err(tag: String, msg: String) = Log.e(tag, msg)
}