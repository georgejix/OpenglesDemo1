package com.dftc.dvr.widget

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.util.AttributeSet
import android.util.Log
import android.view.View
import com.dftc.dvr.R

/**
 * @author: ZJZ
 * @date: 2025/8/15
 * @description：
 */
@SuppressLint("ResourceAsColor")
class StorageProgressView @JvmOverloads constructor(context: Context,
                                                    attrs: AttributeSet? = null, defStyleAttr: Int = 0) : View(context, attrs, defStyleAttr) {


    private val TAG = "StorageProgressView"
    private var progress1 = 0f // 当前进度 (0~100)
    private var progress2 = 0f // 当前进度 (0~100)
    private var progress3 = 0f // 当前进度 (0~100)
    private var progressColor1 = resources.getColor(R.color.color_02B35A) // 渐变开始色
    private var progressColor2 = resources.getColor(R.color.color_FFA800) // 渐变开始色
    private var progressColor3 = resources.getColor(R.color.color_3C6FF1) // 渐变开始色
    private var backgroundColor = Color.LTGRAY // 背景色
    private var cornerRadius = 20f // 圆角半径，默认20dp

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG)




    // 设置四个角的圆角半径（左上、右上、右下、左下）
    val radii = floatArrayOf(cornerRadius, cornerRadius,  // 左上
        cornerRadius, cornerRadius,                     // 右上
        cornerRadius, cornerRadius,                     // 右下
        cornerRadius, cornerRadius   // 左下
    )




    init {
        //自定义属性
        context.theme.obtainStyledAttributes(attrs, R.styleable.CustomProgressBar, 0, 0).apply {
            try {
                progress1 = getFloat(R.styleable.CustomProgressBar_progress, 0f)
                progressColor1 = getColor(R.styleable.CustomProgressBar_progress_color_1, resources.getColor(R.color.color_02B35A))
                progressColor2 = getColor(R.styleable.CustomProgressBar_progress_color_2, resources.getColor(R.color.color_FFA800))
                progressColor3 = getColor(R.styleable.CustomProgressBar_progress_color_3, resources.getColor(R.color.color_3C6FF1))
                backgroundColor = getColor(R.styleable.CustomProgressBar_backgroundColor, Color.LTGRAY)
                cornerRadius = getDimension(R.styleable.CustomProgressBar_cornerRadius, 20f)
            } finally {
                recycle()
            }
        }
    }
    private val path = Path()
    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val width = width.toFloat()
        val height = height.toFloat()
        Log.i(TAG,"onDraw --- > width : $width -- height : $height")
        // 绘制背景 (带圆角)
        backgroundPaint.color = backgroundColor
        canvas.drawRoundRect(0f, 0f, width, height, cornerRadius, cornerRadius, backgroundPaint)

//        if(progress1 > 0) {
//            progressPaint.color = progressColor1
//            canvas.drawRoundRect(0f, 0f, progress1, height, cornerRadius, cornerRadius, progressPaint)
//        }
//
//
//        progressPaint.color = progressColor2
//        canvas.drawRoundRect(progress1 - cornerRadius, 0f, progress2, height, cornerRadius, cornerRadius, progressPaint)
//
//        progressPaint.color = progressColor3
//        canvas.drawRoundRect(progress2 - cornerRadius, 0f, progress3, height, cornerRadius, cornerRadius, progressPaint)



        path.reset()
        path.addRoundRect(0f, 0f, progress3, height, radii, Path.Direction.CW)
        progressPaint.color = progressColor3
        canvas.drawPath(path, progressPaint)


        path.reset()
        path.addRoundRect(0f, 0f, progress2, height, getRadius2(), Path.Direction.CW)
        progressPaint.color = progressColor2
        canvas.drawPath(path, progressPaint)

        path.reset()
        path.addRoundRect(0f, 0f, progress1, height, getRadius1(), Path.Direction.CW)
        progressPaint.color = progressColor1
        canvas.drawPath(path, progressPaint)



//        /**
//         * 如果进度3是0，则进度2需要带圆角，否则圆角在进度3上
//         */
//        progressPaint.color = progressColor2
//        if (progress3 == 0f) {
//            canvas.drawRoundRect(0f, 0f, progress2, height, cornerRadius, cornerRadius, progressPaint)
//        } else {
//            canvas.drawRoundRect(0f, 0f, progress2, height, 0f, 0f, progressPaint)
//        }
//
//
//        /**
//         * 如果进度3和进度2都是是0，则进度1右边需要带圆角，否则圆角在其它进度上
//         */
//        progressPaint.color = progressColor1
//        if (progress3 == 0f && progress2 == 0f) {
//            canvas.drawRoundRect(0f, 0f, progress1, height, cornerRadius, cornerRadius, progressPaint)
//        } else {
//            canvas.drawRoundRect(0f, 0f, progress1, height, cornerRadius, cornerRadius, progressPaint)
//        }
    }


    private fun getRadius2() : FloatArray{
        if (progress3 == 0f) {
            //进度3为0的话，进度后右边需要圆角
            return floatArrayOf(cornerRadius, cornerRadius,  // 左上
                cornerRadius, cornerRadius,                     // 右上
                cornerRadius, cornerRadius,                     // 右下
                cornerRadius, cornerRadius   // 左下
            )
        } else {
            return floatArrayOf(cornerRadius, cornerRadius,  // 左上
                0f, 0f,                     // 右上
                0f, 0f,                     // 右下
                cornerRadius, cornerRadius   // 左下
            )
        }
    }

    private fun getRadius1() : FloatArray{
        if (progress3 == 0f && progress2 == 0f) {
            //进度3和进度2都为0的话，进度1后右边需要圆角
            return floatArrayOf(cornerRadius, cornerRadius,  // 左上
                cornerRadius, cornerRadius,                     // 右上
                cornerRadius, cornerRadius,                     // 右下
                cornerRadius, cornerRadius   // 左下
            )
        } else {
            return floatArrayOf(cornerRadius, cornerRadius,  // 左上
                0f, 0f,                     // 右上
                0f, 0f,                     // 右下
                cornerRadius, cornerRadius   // 左下
            )
        }
    }

    /**
     * max  总空间
     * p1   循环录像
     * p2   紧急录像
     * p3   哨兵录像
     */
    fun setProgress(max : Float, p1 : Float, p2 : Float, p3 : Float) {
        progress1 = if (p1 == 0f) 0f else p1 * 960f / max
        progress2 = if (p2 == 0f) 0f else (p1 + p2) * 960f / max
        progress3 = if (p3 == 0f) 0f else (p1 + p2 + p3) * 960f / max
        Log.i(TAG,"setProgress --- > progress1 : $progress1 -- progress2 :$progress2 -- progress3 : $progress3")
        invalidate()
    }
}