plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("kotlin-parcelize")
}

android {
    namespace = "com.dftc.dvraidl"
    compileSdk = 34

    defaultConfig {
        minSdk = 24

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        consumerProguardFiles("consumer-rules.pro")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        aidl = true
    }
    afterEvaluate {
        libraryVariants.all { variant ->
            val outputFile = variant.outputs.first().outputFile
            tasks.named("assemble${variant.name.capitalize()}") {
                doLast {
                    copy {
                        from(outputFile)
                        into("../apk/")
                        rename(outputFile.name, "dfdvr_aidl.aar")
                    }
                    copy {
                        from(outputFile)
                        into("../app/libs/")
                        rename(outputFile.name, "dfdvr_aidl.aar")
                    }
                    copy {
                        from(outputFile)
                        into("../service/libs/")
                        rename(outputFile.name, "dfdvr_aidl.aar")
                    }
                }
            }
            true
        }
    }
}
dependencies {
}