package com.dftc.dvraidl.bean

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


/**
 * @author: ZJZ
 * @date: 2025/9/2
 * @description：
 */
@Parcelize
data class RecordInfo(var name : String) : Parcelable {

}
