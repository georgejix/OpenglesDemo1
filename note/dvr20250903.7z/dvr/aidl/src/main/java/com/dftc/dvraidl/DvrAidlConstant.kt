package com.dftc.dvraidl

import android.content.ComponentName
import android.content.Intent

object DvrAidlConstant {
    val PREVIEW_TYPE_DVR = 0
    val PREVIEW_TYPE_AVM_FRONT = 1
    val PREVIEW_TYPE_AVM_BACK = 2
    val PREVIEW_TYPE_AVM_LEFT = 3
    val PREVIEW_TYPE_AVM_TIGHT = 4
    val dvrPreviewIntent = Intent().apply {
        component =
            ComponentName("com.dftc.dvrservice", "com.dftc.dvrservice.DvrPreviewService")
    }
}